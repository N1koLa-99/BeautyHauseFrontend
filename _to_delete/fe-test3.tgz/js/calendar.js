/* =====================================================================
   График за служител/шеф.
   Calendar.mount(container, cfg):
     cfg.editable     – true => може ръчно добавяне на час + маркиране
     cfg.shared       – чужд график с достъп (напр. Анелия -> Радина): пълен достъп
                        (часове, статуси, „Запазено“, почивки, почивни дни), но без пари
     cfg.hidePrices   – не показва цени (чужди пари)
     cfg.staffId      – id-то на служителя (за свободни часове)
     cfg.services     – [{serviceId, serviceName, durationMinutes}] (за формата)
     cfg.showEmployee – графикът на целия салон (колона за всяка специалистка)
     cfg.employees    – [{id, name, photo}] (за избора „чий график")
     cfg.workHours    – {0..6: [startMin, endMin] | null} (по избор; иначе часовете на салона)
     cfg.fetchMonth(fromStr, toStr) -> Promise<bookings[]>
     cfg.createBooking(dto) -> Promise            (ако editable)
     cfg.setStatus(id, status) -> Promise         (ако editable)

   Жестове:
     • 2 пръста (или Ctrl + колелце) -> мащаб по часове и по дни
     • иконката горе вляво           -> свий всичко в екрана / разгъни
     • докосване на празно място     -> нов час в този момент
     • задръж + плъзни надолу        -> маркира период (напр. 09:00–12:00) -> нов час с тази продължителност
     • плъзгане настрани (в Ден)     -> предишен/следващ ден
   ===================================================================== */
window.Calendar = (function () {
    const MON = ['Януари', 'Февруари', 'Март', 'Април', 'Май', 'Юни',
        'Юли', 'Август', 'Септември', 'Октомври', 'Ноември', 'Декември'];
    const MON_S = ['яну', 'фев', 'мар', 'апр', 'май', 'юни', 'юли', 'авг', 'сеп', 'окт', 'ное', 'дек'];
    const WD_S = ['нд', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];            // по getDay()
    const WD_MON = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'нд'];          // седмица от понеделник
    const STATUS = {
        booked:    { label: 'Запазен',   cls: 'alert--info' },
        completed: { label: 'Приключен', cls: 'alert--ok' },
        cancelled: { label: 'Отменен',   cls: 'alert--err' },
        no_show:   { label: 'Не се яви', cls: 'alert--err' }
    };
    const pad = n => String(n).padStart(2, '0');
    const key = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;
    const esc = window.esc || (s => String(s ?? ''));
    // Значка „има профил в сайта" (подсказки, банер, попъп).
    const PROF_ICO = `<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>`;
    const profBadge = (txt = 'профил') => `<i class="bh-prof">${PROF_ICO}${txt}</i>`;
    const minToHHMM = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
    const hhmmToMin = v => { const p = (v || '').split(':'); return p.length < 2 ? null : (+p[0]) * 60 + (+p[1]); };
    const addMinIso = (iso, mins) => { const d = new Date(iso); d.setMinutes(d.getMinutes() + mins); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:00`; };
    const WDNAMES = ['неделя', 'понеделник', 'вторник', 'сряда', 'четвъртък', 'петък', 'събота'];
    // Всички клиенти — зареждат се веднъж и се търси в тях на място (подсказките излизат веднага).
    // Опреснява се във фонов режим при всяко отваряне на формата (дотогава се търси в стария списък).
    // Списъкът се пази и в браузъра -> при ново отваряне на сайта подсказките излизат веднага,
    // а пресният списък се тегли отзад. Трие се при изход (auth.js).
    const CL_CACHE = 'bh_cl_cache';
    // Име -> общ вид за търсене: кирилица и латиница (и „шльокавица“) стават едно и също.
    // Мария / Mariq / Maria / Mariya -> „maria“; Йордан / Yordan -> „iordan“; Анна / Ana -> „ana“.
    const TLC = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ж: 'zh', з: 'z', и: 'i', й: 'i', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sht', ъ: 'a', ь: 'i', ю: 'iu', я: 'ia', ы: 'i', э: 'e', ё: 'io' };
    const nameKey = s => String(s || '').toLowerCase()
        .replace(/[а-яёыэ]/g, ch => TLC[ch] ?? ch)
        .replace(/4/g, 'ch').replace(/6/g, 'sh')
        .replace(/q/g, 'ia').replace(/w/g, 'v').replace(/x/g, 'ks').replace(/j/g, 'zh').replace(/y/g, 'i')
        .replace(/c(?!h)/g, 'ts')
        .replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim()
        .replace(/([a-z])\1+/g, '$1');
    const clPrep = r => (r || []).filter(c => c.name).map(c => {
        const n = nameKey(c.name);
        return Object.assign({}, c, { _n: n, _w: n.split(/\s+/), _d: String(c.phone || '').replace(/\D/g, '') });
    });
    const CL = { list: null, at: 0, p: null };
    try { const c = JSON.parse(localStorage.getItem(CL_CACHE) || 'null'); if (Array.isArray(c)) CL.list = clPrep(c); } catch (e) {}
    function clientsLoad(fresh) {
        if (CL.p) return CL.p;
        if (CL.list && CL.at && !(fresh && Date.now() - CL.at > 5000)) return Promise.resolve(CL.list);
        CL.p = window.API.get('/clients').then(r => {
            CL.list = clPrep(r);
            CL.at = Date.now();
            try { localStorage.setItem(CL_CACHE, JSON.stringify((r || []).filter(c => c.name).map(c => ({ key: c.key, name: c.name, phone: c.phone, hasAccount: c.hasAccount, noShow: c.noShow })))); } catch (e) {}
            return CL.list;
        }).finally(() => { CL.p = null; });
        return CL.p;
    }
    // Видимата част от денонощието в графика: 08:00–20:00 (извън нея салонът не работи).
    const DAY_S = 7 * 60 + 30, DAY_E = 20 * 60 + 30, SPAN = DAY_E - DAY_S;   // видимо: 07:30–20:30 (по половин час буфер)
    const BOOK_S = 8 * 60, BOOK_E = 20 * 60;                                 // записване: 08:00–20:00
    const clampM = m => Math.max(DAY_S, Math.min(DAY_E, m));
    // 24-часови опции за час (стъпка 30 мин) — гарантира 24ч формат навсякъде.
    const timeOptions = (selected) => {
        let o = '';
        for (let m = BOOK_S; m <= BOOK_E; m += 30) {
            const v = minToHHMM(m);
            o += `<option value="${v}"${v === selected ? ' selected' : ''}>${v}</option>`;
        }
        return o;
    };
    // Стабилен цвят за всеки специалист (по id).
    // Тоновете са нарочно РАЗЛИЧНИ един от друг (синьо · охра · слива · тюркоаз ·
    // лилаво · маслина), за да се различава от пръв поглед чий е часът. Всички са
    // достатъчно тъмни за четим бял текст (контраст ≥ 4.8:1).
    // Червеното е запазено за некоректни клиенти — затова го няма в списъка.
    // Фиксирани цветове по име: Анелия — синьо, Радина — розово.
    // Останалите получават цвят от палитрата (без синьо и розово, за да не се бъркат).
    const NAME_COLORS = [[/^анелия/i, '#2F6BB0'], [/^радина/i, '#C2185B']];
    const EMP_COLORS = ['#9C6614', '#1F7A6B', '#6B4BA8', '#5E7A1E', '#8A5A44'];
    const empNames = {};
    const learnEmp = (id, name) => { if (id != null && name) empNames[+id] = String(name).trim(); };
    const empColor = id => {
        const n = empNames[+id];
        const m = n && NAME_COLORS.find(([re]) => re.test(n));
        return m ? m[1] : EMP_COLORS[Math.abs(+id || 0) % EMP_COLORS.length];
    };
    // Имената на специалистките (за цветовете) — веднъж при зареждане.
    let empNamesReady = Promise.resolve();
    try {
        if (window.API) empNamesReady = window.API.get('/employees')
            .then(l => (l || []).forEach(e => learnEmp(e.id, e.fullName))).catch(() => {});
    } catch (e) {}

    // Бялата (работна) част на графика = работното време на салона: пн–пт 09:00–18:30,
    // сб 10:00–14:30. Извън него е сиво, но пак може да се записва ръчно — записването
    // е 08:00–20:00 (BOOK_S/BOOK_E). Неделя остава сива (салонът е затворен).
    // Почивка след процедура (мин) — като WorkingHours.RestBufferMinutes в backend-а.
    const REST_MIN = 10;
    // В избора на услуга персоналът вижда колко заема часът в графика:
    // процедура + почивка, в часове (90 мин -> „1 ч 40 мин“).
    const svcDurLabel = d => { const t = d + REST_MIN, h = Math.floor(t / 60), m = t % 60; return h ? `${h} ч${m ? ` ${m} мин` : ''}` : `${m} мин`; };
    const SALON_HOURS = { 0: null, 1: [540, 1110], 2: [540, 1110], 3: [540, 1110], 4: [540, 1110], 5: [540, 1110], 6: [600, 870] };

    // Геометрия на решетката. --hh = пиксели за 1 час, --cw = ширина на колона.
    const HH0 = 60, CW0 = 105, GUT = 50, HEAD = 46, SNAP = 15;
    const Z_MIN = 0.3, Z_MAX = 4, Z_DEF = 1.2;
    // Позиция във времевата решетка като % от денонощието — блокчетата следват
    // височината на колоната сами, без да се пресмятат наново при мащаб.
    // pct(минута) -> позиция; pctD(минути) -> височина. И двете спрямо 08:00–20:00.
    const pct = min => ((clampM(min) - DAY_S) / SPAN * 100).toFixed(4) + '%';
    const pctD = d => (d / SPAN * 100).toFixed(4) + '%';
    const VIEWS = [['day', 'Ден'], ['3day', '3 дни'], ['week', 'Седмица'], ['month', 'Месец']];

    const ICO = {
        prev: '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M15.5 5 7.5 12l8 7z" fill="currentColor"/></svg>',
        next: '<svg viewBox="0 0 24 24" width="24" height="24"><path d="M8.5 5l8 7-8 7z" fill="currentColor"/></svg>',
        today: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none"><rect x="3" y="4.5" width="18" height="16.5" rx="2.4" fill="currentColor" opacity=".38"/><path d="M3 9h18" stroke="currentColor" stroke-width="1.6" opacity=".55"/><path d="M7.5 2.8v3.4M16.5 2.8v3.4" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".6"/><rect x="6.5" y="11.5" width="5" height="5" rx=".8" fill="currentColor" opacity=".75"/></svg>',
        menu: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3.5 6h17M3.5 12h17M3.5 18h17"/></svg>',
        chev: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
        // Стрелки навътре = „свий"; навън = „разгъни".
        compress: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 4l-6.5 6.5M13.5 5.5v5h5M4 20l6.5-6.5M10.5 18.5v-5h-5"/></svg>',
        expand: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13.5 10.5 20 4M15 4h5v5M10.5 13.5 4 20M9 20H4v-5"/></svg>',
        people: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="9" cy="8.5" r="3.2"/><path d="M3 19c.9-3.3 3.2-5 6-5s5.1 1.7 6 5"/><circle cx="16.5" cy="9" r="2.6"/><path d="M16 14.1c2.4 0 4.3 1.5 5 4.4"/></svg>',
        check: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>'
    };
    const lsGet = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
    const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} };
    // Последно избраната процедура (за всяка специалистка поотделно, на това устройство).
    // При нов ръчен час тя е избрана направо — Радина записва миглопластика -> следващият път пак е миглопластика.
    const svcRecentKey = empId => 'bh_svc_recent_' + empId;
    const svcRecent = empId => { try { return JSON.parse(lsGet(svcRecentKey(empId))) || []; } catch (e) { return []; } };
    const rememberSvc = (empId, v) => { if (!v || String(v).startsWith('__')) return; v = String(v); lsSet(svcRecentKey(empId), JSON.stringify([v, ...svcRecent(empId).filter(x => x !== v)].slice(0, 5))); };
    // Слага последната процедура в <select>-а, ако я има в списъка на специалистката.
    const selectLastSvc = (sel, empId) => {
        const v = svcRecent(empId).find(x => [...sel.options].some(o => o.value === x));
        if (v) sel.value = v;
        return !!v;
    };

    // ---- Бърз избор на услуга: търсене + категории + последно избирани ----
    // Стои върху обикновения <select> (той остава източникът на стойността), така че
    // останалият код (зареждане, продължителност, запис) работи както преди.
    const svcNorm = s => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
    const LAT = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sht', ъ: 'a', ь: 'y', ю: 'yu', я: 'ya' };
    // И „мигли", и „migli" намират едно и също.
    const toLat = s => svcNorm(s).replace(/[а-я]/g, c => LAT[c] || c);
    let catIndex = null;
    function svcCatalog() {
        if (catIndex) return catIndex;
        catIndex = new Map();
        let i = 0;
        (window.BH_CATALOG || []).forEach(c => c.groups.forEach(g => g.items.forEach(it => {
            const put = db => { const k = svcNorm(db); if (k && !catIndex.has(k)) catIndex.set(k, { cat: c.label, group: g.name, order: i++ }); };
            if (it.options) it.options.forEach(o => put(o.db)); else put(it.db || it.name);
        })));
        return catIndex;
    }

    function svcPicker(sel, recentKey) {
        const wrap = document.createElement('div');
        // В попъпа списъкът се отваря върху целия попъп (не го удължава).
        const sheet = !!sel.closest('.cal-modal');
        wrap.className = 'svp' + (sheet ? ' svp--sheet' : '');
        wrap.innerHTML = `<button type="button" class="select svp-btn"></button>
            <div class="svp-pop" hidden>
                <div class="svp-top"><button type="button" class="svp-back" aria-label="Назад"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button><span>Избери услуга</span></div>
                <input class="input svp-q" type="search" placeholder="Търси услуга… (гел, лице, мигли)" autocomplete="off" enterkeyhint="done">
                <div class="svp-cats"></div>
                <div class="svp-list" role="listbox"></div>
            </div>`;
        sel.hidden = true;
        sel.after(wrap);
        const btn = wrap.querySelector('.svp-btn'), pop = wrap.querySelector('.svp-pop');
        const qEl = wrap.querySelector('.svp-q'), catsEl = wrap.querySelector('.svp-cats'), listEl = wrap.querySelector('.svp-list');
        let q = '', cat = '', act = 0, shown = [];

        const recent = () => svcRecent(recentKey());
        const remember = v => rememberSvc(recentKey(), v);

        function items() {
            const idx = svcCatalog();
            return [...sel.options].filter(o => o.value).map(o => {
                const m = o.text.match(/^(.*) · (\d+) мин$/);
                const name = m ? m[1] : o.text;
                if (o.value.startsWith('__'))
                    return { v: o.value, name, dur: null, cat: 'Без клиент', group: 'Без клиент', order: -1, hay: toLat(`${name} почивка почивен ден запазено зает блокирай`) };
                const c = idx.get(svcNorm(name));
                return { v: o.value, name, dur: m ? +m[2] : null, cat: c ? c.cat : 'Други', group: c ? c.group : 'Други', order: c ? c.order : 1e6,
                    hay: toLat(`${name} ${c ? c.cat + ' ' + c.group : ''}`) };
            }).sort((a, b) => a.order - b.order || a.name.localeCompare(b.name, 'bg'));
        }
        // Удебелява написаното в името (когато е на кирилица, както е в името).
        function hl(name) {
            const low = name.toLowerCase(), marks = [];
            svcNorm(q).split(' ').filter(Boolean).forEach(w => { const i = low.indexOf(w); if (i >= 0) marks.push([i, i + w.length]); });
            marks.sort((a, b) => a[0] - b[0]);
            let out = '', at = 0;
            marks.forEach(([s, e]) => { if (s < at) return; out += esc(name.slice(at, s)) + `<mark>${esc(name.slice(s, e))}</mark>`; at = e; });
            return out + esc(name.slice(at));
        }

        function paintBtn() {
            const o = sel.selectedOptions[0];
            const m = o && o.value && o.text.match(/^(.*) · (\d+) мин$/);
            btn.disabled = !items().length;
            btn.innerHTML = m ? `<span>${esc(m[1])}</span><small>${svcDurLabel(+m[2])}</small>` : `<span>${esc(o ? o.text : '')}</span>`;
        }
        function renderList() {
            const all = items(), words = toLat(q).split(' ').filter(Boolean);
            const cats = [...new Set(all.map(i => i.cat))];
            catsEl.innerHTML = cats.length > 1 ? ['', ...cats].map(c =>
                `<button type="button" class="svp-cat${c === cat ? ' is-on' : ''}" data-c="${esc(c)}">${c ? esc(c) : 'Всички'}</button>`).join('') : '';
            shown = [];
            const row = it => `<button type="button" class="svp-it${it.v === sel.value ? ' is-sel' : ''}" data-i="${shown.push(it) - 1}" role="option"><span>${hl(it.name)}</span>${it.dur ? `<small>${svcDurLabel(it.dur)}</small>` : ''}</button>`;
            let html = '';
            if (!q && !cat) {
                const rec = recent().map(v => all.find(i => i.v === v)).filter(Boolean);
                if (rec.length) html += `<div class="svp-h">Последно избирани</div>` + rec.map(row).join('');
            }
            let g = null;
            all.filter(it => (!cat || it.cat === cat) && words.every(w => it.hay.includes(w))).forEach(it => {
                const h = it.group === 'Други' ? 'Други' : ((cat || it.cat === it.group) ? it.group : `${it.cat} · ${it.group}`);
                if (h !== g) { g = h; html += `<div class="svp-h">${esc(h)}</div>`; }
                html += row(it);
            });
            listEl.innerHTML = html || `<div class="svp-empty">Няма услуга с „${esc(q)}“</div>`;
            act = Math.min(act, Math.max(0, shown.length - 1));
            paintAct();
        }
        function paintAct(center) {
            listEl.querySelectorAll('.svp-it.is-act').forEach(x => x.classList.remove('is-act'));
            const el = listEl.querySelector(`.svp-it[data-i="${act}"]`);
            if (el) { el.classList.add('is-act'); el.scrollIntoView({ block: center ? 'center' : 'nearest' }); }
        }

        function open() {
            if (btn.disabled) return;
            q = ''; cat = ''; qEl.value = '';
            pop.hidden = false; wrap.classList.add('is-open');
            renderList();
            act = Math.max(0, shown.findIndex(i => i.v === sel.value)); paintAct(true);
            if (!sheet) wrap.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            // На компютър -> направо се пише; на телефон клавиатурата не изскача сама.
            if (matchMedia('(hover: hover) and (pointer: fine)').matches) qEl.focus({ preventScroll: true });
        }
        function close() { pop.hidden = true; wrap.classList.remove('is-open'); }
        function pick(it) {
            if (!it) return;
            sel.value = it.v;
            sel.dispatchEvent(new Event('change'));
            remember(it.v);
            paintBtn(); close();
        }

        btn.addEventListener('click', () => pop.hidden ? open() : close());
        wrap.querySelector('.svp-back').addEventListener('click', () => { close(); btn.focus(); });
        qEl.addEventListener('input', () => { q = qEl.value; act = 0; renderList(); listEl.scrollTop = 0; });
        qEl.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                act = Math.max(0, Math.min(shown.length - 1, act + (e.key === 'ArrowDown' ? 1 : -1))); paintAct();
            } else if (e.key === 'Enter') { e.preventDefault(); pick(shown[act]); }
            else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); btn.focus(); }
        });
        catsEl.addEventListener('click', (e) => {
            const c = e.target.closest('.svp-cat'); if (!c) return;
            cat = c.dataset.c; act = 0; renderList(); listEl.scrollTop = 0;
        });
        listEl.addEventListener('click', (e) => { const b = e.target.closest('.svp-it'); if (b) pick(shown[+b.dataset.i]); });
        const outside = (e) => {
            if (!document.body.contains(wrap)) { document.removeEventListener('pointerdown', outside, true); return; }
            if (!pop.hidden && !wrap.contains(e.target)) close();
        };
        document.addEventListener('pointerdown', outside, true);
        // Списъкът се сменя (друга специалистка, зареждане…) -> бутонът се обновява.
        new MutationObserver(() => { paintBtn(); if (!pop.hidden) renderList(); }).observe(sel, { childList: true });
        paintBtn();
    }

    function mount(container, cfg) {
        if (cfg && cfg.editable) clientsLoad(true).catch(() => {});   // подсказките са готови преди първия „Нов час“
        const todayKey = () => { const d = new Date(); return key(d.getFullYear(), d.getMonth(), d.getDate()); };
        const nowMin = () => { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); };
        // ?date=YYYY-MM-DD (напр. от push известие) -> графикът се отваря на тази дата.
        const urlDate = (() => { try { const v = new URLSearchParams(location.search).get('date'); return /^\d{4}-\d{2}-\d{2}$/.test(v || '') && !isNaN(new Date(v)) ? v : null; } catch (e) { return null; } })();
        let selKey = urlDate || todayKey();
        let data = {};            // 'YYYY-MM-DD' -> [bookings]
        let offs = {};            // 'YYYY-MM-DD' -> [почивки {kind:'rest'} / почивен ден {kind:'off'}]
        // избрана специалистка (null = всички). cfg.initialEmp -> графикът се отваря само с нейните часове
        // (зарежда се по-малко от сървъра); „Всички“ се теглят чак като ги избере.
        let empFilter = cfg.initialEmp != null ? cfg.initialEmp : null;
        let view = VIEWS.some(v => v[0] === lsGet('bh_sc_view')) ? lsGet('bh_sc_view') : 'week';
        const clampZoom = z => Math.min(Z_MAX, Math.max(Z_MIN, z));
        let zoom = clampZoom(parseFloat(lsGet('bh_sc_zoom')) || Z_DEF);
        // Прагове за натовареност (Радина ги задава от Настройки; пазят се локално).
        const loadY = parseInt(lsGet('bh_load_yellow'), 10) || 10;
        const loadR = parseInt(lsGet('bh_load_red'), 10) || 15;
        const workHours = cfg.workHours || SALON_HOURS;

        container.innerHTML = `
            <div class="sc">
                <div class="sc-bar">
                    <button type="button" class="sc-date" aria-label="Избери дата"><span class="sc-date__d"></span><span class="sc-date__w"></span></button>
                    <div class="sc-bar__mid">
                        <button type="button" class="sc-ic sc-prev" aria-label="Назад">${ICO.prev}</button>
                        <button type="button" class="sc-ic sc-today" aria-label="Днес">${ICO.today}</button>
                        <button type="button" class="sc-ic sc-next" aria-label="Напред">${ICO.next}</button>
                    </div>
                    <button type="button" class="sc-ic sc-menu" aria-label="Изглед">${ICO.menu}</button>
                </div>
                <div class="sc-pop sc-pop--date" hidden></div>
                <div class="sc-pop sc-pop--menu" hidden></div>
                <div class="sc-scroll"></div>
                <button type="button" class="sc-fab sc-fab--ok" aria-label="Запази времето (без клиент)" title="Запази времето (без клиент)" hidden>${ICO.check}</button>
                <div class="sc-fabs">
                    <button type="button" class="sc-fab sc-fab--who" aria-label="Чий график" hidden></button>
                    <button type="button" class="sc-fab sc-fab--add" aria-label="Нов час" hidden>
                        <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
                    </button>
                </div>
                <div class="sc-zoom" role="group" aria-label="Мащаб">
                    <button type="button" class="sc-zoom__b sc-zoom-out" aria-label="Намали" title="Намали (Ctrl −)">−</button>
                    <button type="button" class="sc-zoom__v" title="Нормален мащаб (Ctrl 0)"></button>
                    <button type="button" class="sc-zoom__b sc-zoom-in" aria-label="Увеличи" title="Увеличи (Ctrl +)">+</button>
                </div>
                <div class="sc-sheet" hidden></div>
                <div class="sc-loading" hidden><div class="spinner"></div></div>
            </div>
            <div class="sc-below"></div>`;

        const root = container.querySelector('.sc');
        const scroll = root.querySelector('.sc-scroll');
        const dateBtn = root.querySelector('.sc-date');
        const popDate = root.querySelector('.sc-pop--date');
        const popMenu = root.querySelector('.sc-pop--menu');
        const sheet = root.querySelector('.sc-sheet');
        const fabWho = root.querySelector('.sc-fab--who');
        const fabAdd = root.querySelector('.sc-fab--add');
        const fabOk = root.querySelector('.sc-fab--ok');
        let pend = null;   // маркиран, но още непотвърден период (виж finishSelect)
        const loadingEl = root.querySelector('.sc-loading');
        const below = container.querySelector('.sc-below');

        // ---- Специалистки ----
        function empsSorted(ORDER = ['ирина', 'радина', 'анелия']) {
            const rank = n => { const s = (n || '').toLowerCase(); const i = ORDER.findIndex(o => s.includes(o)); return i < 0 ? ORDER.length : i; };
            return (cfg.employees || []).slice().sort((a, b) => rank(a.name) - rank(b.name) || String(a.name).localeCompare(String(b.name), 'bg'));
        }
        const firstName = n => String(n || '').trim().split(/\s+/)[0] || 'Специалист';
        const hasEmps = () => !!(cfg.showEmployee && cfg.employees && cfg.employees.length);
        const photoOf = e => e.photo || ((typeof TEAM_PHOTO_BY_NAME !== 'undefined' && TEAM_PHOTO_BY_NAME[e.name]) || '');
        const avatarHtml = (e, size) => {
            const p = photoOf(e);
            return p
                ? `<img class="sc-av" src="${esc(p)}" alt="" style="width:${size}px;height:${size}px;--c:${empColor(e.id)}">`
                : `<span class="sc-av sc-av--i" style="width:${size}px;height:${size}px;background:${empColor(e.id)};font-size:${Math.round(size * .42)}px">${esc(firstName(e.name).charAt(0))}</span>`;
        };
        const canAdd = () => !!(cfg.editable && cfg.createBooking &&
            (cfg.staffId || (hasEmps() && cfg.servicesFor)));

        // ---- Дати ----
        const parseK = k => new Date(k + 'T00:00:00');
        const kOf = d => key(d.getFullYear(), d.getMonth(), d.getDate());
        const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
        const mondayOf = d => addDays(d, -((d.getDay() + 6) % 7));
        const toMin = iso => (+iso.slice(11, 13)) * 60 + (+iso.slice(14, 16));
        const endMin = b => b.endAt ? toMin(b.endAt) : toMin(b.startAt) + 30;
        const listFor = k => { const a = data[k] || []; return empFilter != null ? a.filter(b => b.employeeId === empFilter) : a; };
        // Застъпване: ръчно въведен час може да легне върху друг час на същата специалистка
        // (онлайн през сайта — никога). Такива часове се оцветяват в червено, за да се оправят.
        const isActiveBk = b => b.status === 'booked' || b.status === 'completed';
        // Застъпване на час с друг час ИЛИ с почивка/„Запазено“, и на блок с час — за същата специалистка.
        // Връща [{ b } | { r }] (час / блок).
        const clashesOf = (b, isBlock) => {
            if (!b || (!isBlock && !isActiveBk(b))) return [];
            const k = b.startAt.slice(0, 10), s = b.startAt.slice(0, 16), e = (b.endAt || b.startAt).slice(0, 16);
            const hit = x => x.employeeId === b.employeeId && x.startAt.slice(0, 16) < e && (x.endAt || x.startAt).slice(0, 16) > s;
            const bks = (data[k] || []).filter(x => (isBlock || x.id !== b.id) && isActiveBk(x) && hit(x)).map(x => ({ b: x }));
            const rs = isBlock ? [] : (offs[k] || []).filter(o => o.kind === 'rest' && hit(o)).map(o => ({ r: o }));
            return bks.concat(rs);
        };
        const clashLabel = c => c.b
            ? `${c.b.startAt.slice(11, 16)}–${(c.b.endAt || '').slice(11, 16)} · ${esc(c.b.clientName || 'Клиент')} · ${esc(c.b.serviceName)}`
            : `${c.r.startAt.slice(11, 16)}–${c.r.endAt.slice(11, 16)} · ${c.r.blockType === 'reserved' ? 'Запазено' : 'Почивка'}${c.r.note ? ' · ' + esc(c.r.note) : ''}`;
        const offsFor = k => { const a = offs[k] || []; return empFilter != null ? a.filter(o => o.employeeId === empFilter) : a; };
        // Почивки/почивни дни: за служител (собствения график) и шефа (чужд / целия салон).
        const canRest = () => !!(cfg.editable && (cfg.staffId || hasEmps()));
        const ITEM_SEL = '.sc-bk, .sc-dayoff, .sc-offtag, .sc-sel.is-pend';

        function visibleDays() {
            const sd = parseK(selKey);
            if (view === 'day') return [sd];
            if (view === '3day') return [0, 1, 2].map(i => addDays(sd, i));
            if (view === 'week') { const m = mondayOf(sd); return [0, 1, 2, 3, 4, 5, 6].map(i => addDays(m, i)); }
            const first = new Date(sd.getFullYear(), sd.getMonth(), 1), m = mondayOf(first);
            const last = new Date(sd.getFullYear(), sd.getMonth() + 1, 0);
            const cells = Math.ceil((Math.round((last - m) / 864e5) + 1) / 7) * 7;
            return Array.from({ length: cells }, (_, i) => addDays(m, i));
        }
        function visibleMonths() {
            const seen = new Set(), out = [];
            visibleDays().forEach(d => { const mk = `${d.getFullYear()}-${d.getMonth()}`; if (!seen.has(mk)) { seen.add(mk); out.push([d.getFullYear(), d.getMonth()]); } });
            return out;
        }

        // ---- Данни (кеш по месеци) ----
        // Месец -> какво е заредено за него: 'all' (всички специалистки) или id на една.
        const loadedMonths = new Map();
        const scopeNow = () => (hasEmps() && empFilter != null) ? empFilter : 'all';
        const monthOk = mk => { const s = loadedMonths.get(mk); return s === 'all' || (s != null && s === scopeNow()); };
        (cfg.employees || []).forEach(e => learnEmp(e.id, e.name));
        // Щом имената пристигнат -> пренарисува с правилните цветове.
        empNamesReady.then(() => { if (loadedMonths.size && document.body.contains(root)) render(); });
        async function fetchMonthInto(Y, M0) {
            const from = key(Y, M0, 1);
            const to = `${M0 === 11 ? Y + 1 : Y}-${pad((M0 + 1) % 12 + 1)}-01`;
            const scope = scopeNow();
            const rangeQ = !hasEmps() ? `employeeId=${cfg.staffId}` : (scope === 'all' ? 'all=true' : `employeeId=${scope}`);
            const [items, rng] = await Promise.all([
                cfg.fetchMonth(from, to, scope === 'all' ? null : scope),
                // Почивките не са задължителни за графика -> грешка тук не спира зареждането.
                (canRest() || cfg.shared) ? window.API.get(`/schedule/range?${rangeQ}&from=${from}&to=${to}`).catch(() => null) : null
            ]);
            const inMonth = dk => { const dt = parseK(dk); return dt.getFullYear() === Y && dt.getMonth() === M0; };
            for (const dk of Object.keys(data)) if (inMonth(dk)) delete data[dk];
            for (const dk of Object.keys(offs)) if (inMonth(dk)) delete offs[dk];
            (items || []).forEach(b => { learnEmp(b.employeeId, b.employeeName); const k = b.startAt.slice(0, 10); (data[k] = data[k] || []).push(b); });
            ((rng && rng.blocks) || []).forEach(r => learnEmp(r.employeeId, r.employeeName));
            if (rng) {
                (rng.blocks || []).forEach(r => { const k = r.startAt.slice(0, 10); (offs[k] = offs[k] || []).push({ kind: 'rest', ...r }); });
                (rng.offDays || []).forEach(o => { const k = String(o.date).slice(0, 10); (offs[k] = offs[k] || []).push({ kind: 'off', employeeId: o.employeeId, employeeName: o.employeeName, k }); });
            }
            loadedMonths.set(`${Y}-${M0}`, scope);
        }
        // Зарежда липсващите видими месеци (force = презарежда ги пак — след промяна).
        async function ensureVisible(force) {
            const need = visibleMonths().filter(([Y, M0]) => force || !monthOk(`${Y}-${M0}`));
            if (need.length) {
                loadingEl.hidden = false;
                try { for (const [Y, M0] of need) await fetchMonthInto(Y, M0); }
                catch (err) { loadingEl.hidden = true; scroll.innerHTML = `<div class="alert alert--err" style="margin:1rem">${esc(err.message)}</div>`; return; }
                loadingEl.hidden = true;
            }
            render();
        }
        function load() { belowKey = ''; return ensureVisible(true); }   // презареждане (след промяна)
        function navigate() { return ensureVisible(false); }  // навигация (зарежда само липсващото)

        function goToDate(k) { selKey = k; navigate(); }
        function setView(v) { view = v; lsSet('bh_sc_view', v); navigate(); }
        function shift(dir) {
            const sd = parseK(selKey);
            if (view === 'month') {
                const t = new Date(sd.getFullYear(), sd.getMonth() + dir, 1);
                const dim = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
                t.setDate(Math.min(sd.getDate(), dim));
                goToDate(kOf(t));
            } else goToDate(kOf(addDays(sd, dir * (view === 'week' ? 7 : view === '3day' ? 3 : 1))));
        }

        root.querySelector('.sc-prev').addEventListener('click', () => shift(-1));
        root.querySelector('.sc-next').addEventListener('click', () => shift(1));
        root.querySelector('.sc-today').addEventListener('click', () => { closePops(); pendingScroll = 'now'; goToDate(todayKey()); });

        // ================= Рисуване =================
        let lastLayout = '', pendingScroll = 'start';
        function render() {
            clearPend();
            paintBar();
            paintFabs();
            { const zw = root.querySelector('.sc-zoom'); if (zw) zw.hidden = view === 'month'; }
            if (view === 'month') renderMonth(); else renderGrid();
            renderBelow();
        }

        function paintBar() {
            const sd = parseK(selKey);
            const d = root.querySelector('.sc-date__d'), w = root.querySelector('.sc-date__w');
            if (view === 'month') { d.innerHTML = `${MON[sd.getMonth()].toUpperCase()} ${ICO.chev}`; w.textContent = sd.getFullYear(); }
            else { d.innerHTML = `${sd.getDate()} ${MON_S[sd.getMonth()].toUpperCase()} ${ICO.chev}`; w.textContent = WDNAMES[sd.getDay()]; }
        }

        function paintFabs() {
            fabAdd.hidden = !canAdd();
            fabWho.hidden = !hasEmps();
            if (!hasEmps()) return;
            const e = empFilter != null && cfg.employees.find(x => x.id === empFilter);
            fabWho.innerHTML = e ? avatarHtml(e, 56) : `<span class="sc-fab__all">${ICO.people}</span>`;
            fabWho.style.setProperty('--c', e ? empColor(e.id) : 'var(--sc-accent)');
        }

        // Колони на времевата решетка: дни, или (Ден + „Всички") — по една за всяка специалистка.
        function columns() {
            const days = visibleDays();
            if (view === 'day' && hasEmps() && empFilter == null)
                return empsSorted().map(e => ({ k: selKey, d: days[0], emp: e }));
            return days.map(d => ({ k: kOf(d), d, emp: null }));
        }

        function blocksHtml(items, rests) {
            const arr = items.map(b => ({ b, s: toMin(b.startAt), e: endMin(b) }))
                .concat((rests || []).map(r => ({ r, s: toMin(r.startAt), e: r.endAt.slice(0, 10) > r.startAt.slice(0, 10) ? 1440 : toMin(r.endAt) })))
                .map(x => {
                    x.s = Math.min(clampM(x.s), DAY_E - 15);
                    x.e = Math.max(clampM(x.e), x.s + 15);
                    return x;
                })
                .sort((x, y) => x.s - y.s || x.e - y.e);
            const laneEnd = [], laneOf = [];
            arr.forEach((x, i) => {
                let l = laneEnd.findIndex(v => v <= x.s);
                if (l === -1) { l = laneEnd.length; laneEnd.push(x.e); } else laneEnd[l] = x.e;
                laneOf[i] = l;
            });
            const lanes = Math.max(1, laneEnd.length), dl = Math.min(lanes, 8);
            const nowStamp = `${todayKey()}T${minToHHMM(nowMin())}`;
            return arr.map((x, i) => {
                const { s, e } = x, w = 100 / lanes, left = laneOf[i] * w;
                const pos = `top:${pct(s)};height:calc(${pctD(e - s)} - 2px);left:calc(${left}% + 1px);width:calc(${w}% - 2px)`;
                if (x.r) {
                    // Почивка — щрихована; „Запазено" (зает час без клиент) — плътна, в цвета на специалистката.
                    const r = x.r, resv = r.blockType === 'reserved';
                    const who = cfg.showEmployee && empFilter == null ? esc(firstName(r.employeeName)) : '';
                    const rClash = clashesOf(r, true).length > 0;
                    return `<button type="button" class="sc-bk ${resv ? 'sc-resv' : 'sc-rest'}${rClash ? ' is-clash' : ''}" data-l="${dl}" data-rest="${r.id}" data-k="${r.startAt.slice(0, 10)}" style="${pos};--bc:${empColor(r.employeeId)}">
                    <span class="sc-bk__t">${r.startAt.slice(11, 16)}–${minToHHMM(e)}</span>
                    <span class="sc-bk__s">${r.note ? esc(r.note) : (resv ? 'Запазено' : 'Почивка')}</span>
                    ${who ? `<span class="sc-bk__c">${who}</span>` : ''}${rClash ? '<i class="sc-bk__clash" title="Застъпва се със записан час">!</i>' : ''}
                </button>`;
                }
                const b = x.b;
                const flagged = b.noShowCount > 0, noShow = b.status === 'no_show';
                const c = (flagged || noShow) ? '#D9534F' : empColor(b.employeeId);
                const mark = flagged ? ' ⚠' : '';
                const done = b.status === 'completed' ? '<i class="sc-bk__ok" title="Завършен">✓</i>' : '';
                // Минал (вече свършил) час -> по-блед; предстоящ -> по-ярък.
                const past = (b.endAt || b.startAt).slice(0, 16) <= nowStamp;
                const clash = clashesOf(b).length > 0;
                const cls = `sc-bk${clash ? ' is-clash' : ''}${flagged ? ' is-flag' : ''}${b.status === 'completed' ? ' is-done' : ''}${b.status === 'cancelled' ? ' is-cancel' : ''}${past ? ' is-past' : ' is-next'}`;
                const online = b.isOnline
                    ? `<span class="sc-bk__web" title="Записан онлайн през сайта"><svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="12" r="9"/><path d="M3.2 12h17.6M12 3.1c2.4 2.6 2.4 15.2 0 17.8M12 3.1c-2.4 2.6-2.4 15.2 0 17.8"/></svg></span>` : '';
                return `<button type="button" class="${cls}" data-l="${dl}" data-id="${b.id}" data-k="${b.startAt.slice(0, 10)}" style="${pos};--bc:${c}">
                    <span class="sc-bk__t">${b.startAt.slice(11, 16)}–${(b.endAt || '').slice(11, 16)}${mark}</span>
                    <span class="sc-bk__s">${esc(b.serviceName)}</span>
                    <span class="sc-bk__c">${esc(b.clientName || 'Клиент')}${cfg.showEmployee && empFilter == null && view !== 'day' ? ' · ' + esc(firstName(b.employeeName)) : ''}</span>
                    ${online}${done}${clash ? '<i class="sc-bk__clash" title="Застъпва се с друг час">!</i>' : ''}
                </button>`;
            }).join('');
        }

        // Почивен ден в колоната: за една специалистка -> щрихова зона през работното време;
        // в обща колона (няколко специалистки) -> етикетче „Почивен · Име" най-горе.
        function dayOffHtml(c, wh) {
            const list = offsFor(c.k).filter(o => o.kind === 'off' && (!c.emp || o.employeeId === c.emp.id));
            if (!list.length) return '';
            const ws = clampM((wh || [540, 1110])[0]), we = clampM((wh || [540, 1110])[1]);
            const single = !!c.emp || !cfg.showEmployee || empFilter != null;
            if (single)
                return `<button type="button" class="sc-dayoff" data-off="${list[0].employeeId}" data-k="${c.k}" style="top:${pct(ws)};height:${pctD(we - ws)};--bc:${empColor(list[0].employeeId)}"><span>Почивен ден</span></button>`;
            return `<div class="sc-offtags" style="top:${pct(ws)}">${list.map(o =>
                `<button type="button" class="sc-offtag" data-off="${o.employeeId}" data-k="${c.k}" style="--bc:${empColor(o.employeeId)}">Почивен · ${esc(firstName(o.employeeName))}</button>`).join('')}</div>`;
        }

        function renderGrid() {
            const cols = columns(), n = cols.length, tk = todayKey(), nm = nowMin();
            let heads = '', bodies = '';
            cols.forEach(c => {
                const wh = workHours[c.d.getDay()];
                if (c.emp) {
                    heads += `<div class="sc-hd sc-hd--emp" style="--c:${empColor(c.emp.id)}">${avatarHtml(c.emp, 26)}<span>${esc(firstName(c.emp.name))}</span></div>`;
                } else {
                    const isToday = c.k === tk, isSel = c.k === selKey && view !== 'day';
                    heads += `<button type="button" class="sc-hd${isToday ? ' is-today' : ''}${isSel ? ' is-sel' : ''}" data-k="${c.k}"><span>${WD_S[c.d.getDay()]}</span> <b>${c.d.getDate()}</b><span class="sc-hd__m"> ${MON_S[c.d.getMonth()]}</span></button>`;
                }
                const items = listFor(c.k).filter(b => !c.emp || b.employeeId === c.emp.id);
                const rests = offsFor(c.k).filter(o => o.kind === 'rest' && (!c.emp || o.employeeId === c.emp.id));
                const work = wh ? `<div class="sc-work" style="top:${pct(wh[0])};height:${pctD(clampM(wh[1]) - clampM(wh[0]))}"></div>` : '';
                const nowL = c.k === tk && nm >= DAY_S && nm <= DAY_E ? `<div class="sc-now" style="top:${pct(nm)}"></div>` : '';
                bodies += `<div class="sc-col" data-k="${c.k}"${c.emp ? ` data-emp="${c.emp.id}"` : ''}>${work}<div class="sc-lines"></div>${dayOffHtml(c, wh)}${blocksHtml(items, rests)}${nowL}</div>`;
            });
            let gut = '';
            // Надпис на всеки 15 мин: кръгъл час (плътно), :30 и :15/:45 (по-дребно).
            for (let m = DAY_S + 15; m < DAY_E; m += 15) {
                const q = m % 60, cls = q === 0 ? (Math.floor(m / 60) % 2 ? ' is-odd' : '') : (q === 30 ? ' sc-gl--h' : ' sc-gl--q');
                gut += `<span class="sc-gl${cls}" style="top:${pct(m)}">${minToHHMM(m)}</span>`;
            }

            const prevTop = scroll.scrollTop, prevLeft = scroll.scrollLeft;
            root.dataset.n = n;
            scroll.innerHTML = `
                <div class="sc-grid">
                    <button type="button" class="sc-corner" aria-label="Свий / разгъни графика"></button>
                    ${heads}
                    <div class="sc-gut">${gut}</div>
                    ${bodies}
                </div>`;
            measure();
            applyZoom(zoom);

            // Скрол: при нов изглед -> към началото на работния ден; иначе остава, където е бил.
            const layout = `${view}|${n}`;
            if (layout !== lastLayout || pendingScroll) {
                const hh = HH0 * zoom;
                if (pendingScroll === 'now' && selKey === tk) scroll.scrollTop = Math.max(0, (clampM(nm) - 90 - DAY_S) / 60 * hh);
                else scroll.scrollTop = Math.max(0, (clampM(firstMinute(cols)) - DAY_S) / 60 * hh - 12);
                // Седмица, която не се побира -> избраният ден да е в началото.
                const idx = cols.findIndex(c => c.k === selKey && !c.emp);
                scroll.scrollLeft = idx > 0 ? idx * curCw() : 0;
            } else { scroll.scrollTop = prevTop; scroll.scrollLeft = prevLeft; }
            lastLayout = layout; pendingScroll = null;
        }
        // Най-ранната минута, която си струва да се вижда: началото на работното време или първият час.
        function firstMinute(cols) {
            let m = 24 * 60;
            cols.forEach(c => {
                const wh = workHours[c.d.getDay()];
                if (wh) m = Math.min(m, wh[0]);
                listFor(c.k).forEach(b => { if (!c.emp || b.employeeId === c.emp.id) m = Math.min(m, toMin(b.startAt)); });
            });
            return m === 24 * 60 ? 9 * 60 : Math.floor(m / 60) * 60;
        }
        function workSpan() {
            const cols = columns();
            let s = 24 * 60, e = 0;
            cols.forEach(c => {
                const wh = workHours[c.d.getDay()];
                if (wh) { s = Math.min(s, wh[0]); e = Math.max(e, wh[1]); }
                listFor(c.k).forEach(b => { s = Math.min(s, toMin(b.startAt)); e = Math.max(e, endMin(b)); });
            });
            if (e <= s) { s = 9 * 60; e = 19 * 60; }
            return [clampM(Math.floor(s / 60) * 60), clampM(Math.ceil(e / 60) * 60)];
        }

        // ---- Мащаб: само CSS променливи -> гладко, без пре-рендиране ----
        // Размерът на полето се чете рядко (рендер / resize), не на всеки кадър от
        // щипката — иначе браузърът пресмята цялата решетка по няколко пъти на кадър.
        let cw = 100, viewW = 0, viewH = 0, ctCache = null;
        const measure = () => { viewW = scroll.clientWidth; viewH = scroll.clientHeight; ctCache = null; };
        const curCw = () => cw;
        function cwFor(z) {
            const n = +root.dataset.n || 1;
            const W = Math.max(120, viewW - GUT);
            const fit = Math.floor(W / n * 100) / 100;
            return n <= 3 ? fit : Math.max(fit, CW0 * z);
        }
        function applyZoom(z) {
            { const zv = root.querySelector('.sc-zoom__v'); if (zv) zv.textContent = Math.round(clampZoom(z) / Z_DEF * 100) + '%'; }
            zoom = clampZoom(z);
            const hh = HH0 * zoom;
            cw = cwFor(zoom);
            // Само размерът на решетката се сменя; всичко вътре е в % -> браузърът
            // не пресмята стиловете на стотиците блокчета на всеки кадър.
            const grid = scroll.querySelector('.sc-grid');
            if (grid) {
                grid.style.gridTemplateColumns = `${GUT}px repeat(${+root.dataset.n || 1}, ${cw.toFixed(2)}px)`;
                grid.style.gridTemplateRows = `${HEAD}px ${(hh * SPAN / 60).toFixed(2)}px`;
                grid.style.setProperty('--sc-hh', hh.toFixed(3) + 'px');   // линиите по часове (графикът започва от :30)
            }
            root.classList.toggle('is-small', hh < 50);
            root.classList.toggle('is-tiny', hh < 30);
            root.classList.toggle('is-narrow', cw < 92);
            // Колко подробни да са часовете вляво, за да не се застъпват надписите.
            root.classList.toggle('no-q', hh < 64);    // без :15 и :45
            root.classList.toggle('no-h', hh < 36);    // без :30
            // Много тесни блокчета (по брой застъпени = data-l) -> само цветът, без смачкан текст.
            for (let L = 1; L <= 8; L++) root.classList.toggle('hl' + L, (cw - 1) / L - 18 <= 34);
            const corner = scroll.querySelector('.sc-corner');
            if (corner) { const c = isCompressed(); if (corner._c !== c) { corner._c = c; corner.innerHTML = c ? ICO.expand : ICO.compress; } }
        }
        // Щипка / колелце идват по много пъти на кадър -> прилагаме само последното, веднъж на кадър.
        let zReq = null, zRaf = 0;
        const pendingZoom = () => zReq ? zReq.z : zoom;
        function zoomAt(z, fx, fy) {
            zReq = { z, fx, fy };
            if (!zRaf) zRaf = requestAnimationFrame(flushZoom);
        }
        function flushZoom() {
            cancelAnimationFrame(zRaf); zRaf = 0;
            const q = zReq; zReq = null;
            if (q) zoomAtNow(q.z, q.fx, q.fy);
        }
        // Мащаб около точка (пръстите / мишката) — тя остава на същото място.
        function zoomAtNow(z, fx, fy) {
            const r = scroll.getBoundingClientRect();
            const px = fx - r.left - GUT, py = fy - r.top - HEAD;
            const hours = (scroll.scrollTop + py) / (HH0 * zoom);
            const colsX = (scroll.scrollLeft + px) / curCw();
            applyZoom(z);
            scroll.scrollTop = hours * HH0 * zoom - py;
            scroll.scrollLeft = colsX * curCw() - px;
        }
        const saveZoom = () => lsSet('bh_sc_zoom', zoom.toFixed(2));
        const compressTarget = () => {
            if (ctCache != null) return ctCache;
            const [s, e] = workSpan();
            const n = +root.dataset.n || 1;
            const zv = (viewH - HEAD - 4) / ((e - s) / 60) / HH0;
            const zh = n > 3 ? (viewW - GUT) / n / CW0 : zv;
            return (ctCache = clampZoom(Math.min(zv, zh)));
        };
        const isCompressed = () => zoom <= compressTarget() + 0.02;

        let tweenId = null;
        function tweenZoom(target, after) {
            cancelAnimationFrame(tweenId);
            zReq = null; cancelAnimationFrame(zRaf); zRaf = 0;
            const from = zoom, t0 = performance.now(), dur = 240;
            const r = scroll.getBoundingClientRect();
            const ease = t => 1 - Math.pow(1 - t, 3);
            const step = (t) => {
                const k = Math.min(1, (t - t0) / dur);
                zoomAtNow(from + (target - from) * ease(k), r.left + GUT, r.top + HEAD);
                if (k < 1) tweenId = requestAnimationFrame(step);
                else { saveZoom(); if (after) after(); }
            };
            tweenId = requestAnimationFrame(step);
        }
        function toggleCompress() {
            if (isCompressed()) tweenZoom(Z_DEF);
            else {
                const s = workSpan()[0];
                tweenZoom(compressTarget(), () => { scroll.scrollTop = (s - DAY_S) / 60 * HH0 * zoom; scroll.scrollLeft = 0; });
            }
        }

        // Промяна на ширината (завъртане, показване на раздела) -> колоните се
        // преизчисляват, а хоризонталният скрол остава на същия ден.
        if (window.ResizeObserver) new ResizeObserver(() => {
            if (view === 'month') return;
            const colsX = scroll.scrollLeft / curCw();
            measure();
            applyZoom(zoom);
            scroll.scrollLeft = Math.round(colsX) * curCw();
        }).observe(scroll);

        // ---- Месечен изглед ----
        function renderMonth() {
            const days = visibleDays(), sd = parseK(selKey), tk = todayKey();
            const rows = days.length / 7;
            const cells = days.map(d => {
                const k = kOf(d), arr = listFor(k).slice().sort((a, b) => a.startAt.localeCompare(b.startAt));
                const other = d.getMonth() !== sd.getMonth();
                const cnt = arr.length;
                const offTags = offsFor(k).filter(o => o.kind === 'off').map(o =>
                    `<span class="sc-mi sc-mi--off" style="--bc:${empColor(o.employeeId)}">Почивен${cfg.showEmployee && empFilter == null ? ' · ' + esc(firstName(o.employeeName)) : ' ден'}</span>`).join('');
                const dot = cnt ? (cnt > loadR ? '#D9534F' : (cnt > loadY ? '#E7B100' : '#4E9E76')) : '';
                const items = arr.slice(0, 3).map(b => {
                    const c = (b.noShowCount > 0 || b.status === 'no_show') ? '#D9534F' : empColor(b.employeeId);
                    const clash = clashesOf(b).length > 0;
                    return `<span class="sc-mi${b.status === 'cancelled' ? ' is-cancel' : ''}${clash ? ' is-clash' : ''}" style="--bc:${c}"><b>${b.startAt.slice(11, 16)}</b> ${clash ? '⚠ ' : ''}${esc(b.serviceName)}</span>`;
                }).join('');
                return `<button type="button" class="sc-mc${other ? ' is-other' : ''}${workHours[d.getDay()] ? '' : ' is-off'}${k === tk ? ' is-today' : ''}${k === selKey ? ' is-sel' : ''}" data-k="${k}">
                    <span class="sc-mc__n">${d.getDate()}${dot ? `<i style="background:${dot}"></i>` : ''}</span>
                    ${offTags}${items}${cnt > 3 ? `<span class="sc-mc__more">+${cnt - 3} още</span>` : ''}
                </button>`;
            }).join('');
            root.dataset.n = 7;
            scroll.innerHTML = `
                <div class="sc-month" style="grid-template-rows:${HEAD - 12}px repeat(${rows}, minmax(92px, 1fr))">
                    ${WD_MON.map(w => `<span class="sc-mh">${w}</span>`).join('')}
                    ${cells}
                </div>`;
            scroll.scrollTop = 0; scroll.scrollLeft = 0;
            lastLayout = 'month';
        }

        // Панел „Работно време" под графика (само собствен график, изглед Ден).
        let belowKey = '';
        function renderBelow() {
            const want = (cfg.editable && !cfg.shared && cfg.staffId && view === 'day') ? selKey : '';
            if (want === belowKey) return;
            belowKey = want;
            if (!want) { below.innerHTML = ''; return; }
            below.innerHTML = `<div class="panel sched-panel" style="margin-top:1.2rem"><div class="spinner"></div></div>`;
            loadSchedule(below.querySelector('.sched-panel'), want);
        }

        // ================= Горна лента: дата + меню =================
        let popM = null; // [Y, M] на мини-календара
        function closePops() { popDate.hidden = true; popMenu.hidden = true; }
        function paintDatePop() {
            const [Y, M] = popM;
            const first = new Date(Y, M, 1), m = mondayOf(first);
            const last = new Date(Y, M + 1, 0);
            const cells = Math.ceil((Math.round((last - m) / 864e5) + 1) / 7) * 7;
            const tk = todayKey();
            let html = '';
            for (let i = 0; i < cells; i++) {
                const d = addDays(m, i), k = kOf(d);
                const cnt = listFor(k).length;
                html += `<button type="button" class="sc-mini__d${d.getMonth() !== M ? ' is-other' : ''}${k === tk ? ' is-today' : ''}${k === selKey ? ' is-sel' : ''}" data-k="${k}">${d.getDate()}${cnt ? '<i></i>' : ''}</button>`;
            }
            popDate.innerHTML = `
                <div class="sc-mini">
                    <div class="sc-mini__nav">
                        <button type="button" class="sc-mini__arr" data-d="-1" aria-label="Предишен месец">${ICO.prev}</button>
                        <strong>${MON[M]} ${Y}</strong>
                        <button type="button" class="sc-mini__arr" data-d="1" aria-label="Следващ месец">${ICO.next}</button>
                    </div>
                    <div class="sc-mini__grid">${WD_MON.map(w => `<span>${w}</span>`).join('')}${html}</div>
                </div>`;
        }
        dateBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const open = popDate.hidden;
            closePops();
            if (!open) return;
            const sd = parseK(selKey); popM = [sd.getFullYear(), sd.getMonth()];
            paintDatePop(); popDate.hidden = false;
        });
        popDate.addEventListener('click', (e) => {
            e.stopPropagation();
            const arr = e.target.closest('.sc-mini__arr');
            if (arr) { const t = new Date(popM[0], popM[1] + (+arr.dataset.d), 1); popM = [t.getFullYear(), t.getMonth()]; paintDatePop(); return; }
            const d = e.target.closest('.sc-mini__d');
            if (d) { closePops(); goToDate(d.dataset.k); }
        });

        root.querySelector('.sc-menu').addEventListener('click', (e) => {
            e.stopPropagation();
            const open = popMenu.hidden;
            closePops();
            if (!open) return;
            popMenu.innerHTML = `
                ${VIEWS.map(([v, lb]) => `<button type="button" class="sc-mn${v === view ? ' is-on' : ''}" data-view="${v}"><span>${lb}</span>${v === view ? ICO.check : ''}</button>`).join('')}
                <div class="sc-mn__sep"></div>
                <div class="sc-mn__zoom"><span>Мащаб</span>
                    <button type="button" class="sc-mn__z" data-z="0.8" aria-label="Намали">−</button>
                    <button type="button" class="sc-mn__z" data-z="1.25" aria-label="Увеличи">+</button>
                </div>`;
            popMenu.hidden = false;
        });
        popMenu.addEventListener('click', (e) => {
            e.stopPropagation();
            const v = e.target.closest('[data-view]');
            if (v) { closePops(); setView(v.dataset.view); return; }
            const z = e.target.closest('[data-z]');
            if (z) { if (view === 'month') setView('week'); tweenZoom(clampZoom(zoom * +z.dataset.z)); }
        });
        document.addEventListener('click', (e) => { if (!root.contains(e.target) || !e.target.closest('.sc-pop')) closePops(); });

        // ================= Плаващи кръгчета =================
        fabWho.addEventListener('click', () => {
            const row = (id, label, av, on) => `<button type="button" class="sc-sh__row${on ? ' is-on' : ''}" data-emp="${id}">${av}<span>${esc(label)}</span>${on ? ICO.check : ''}</button>`;
            sheet.innerHTML = `
                <div class="sc-sh__back"></div>
                <div class="sc-sh__panel">
                    <div class="sc-sh__grab"></div>
                    <div class="sc-sh__title">Чий график да се показва</div>
                    ${row('all', 'Всички', `<span class="sc-av sc-av--all">${ICO.people}</span>`, empFilter == null)}
                    ${empsSorted(['радина', 'анелия', 'ирина']).map(e => row(e.id, e.name, avatarHtml(e, 44), empFilter === e.id)).join('')}
                </div>`;
            sheet.hidden = false;
        });
        sheet.addEventListener('click', (e) => {
            const r = e.target.closest('.sc-sh__row');
            if (r) { empFilter = r.dataset.emp === 'all' ? null : +r.dataset.emp; sheet.hidden = true; lastLayout = ''; navigate(); return; }
            if (e.target.closest('.sc-sh__back')) sheet.hidden = true;
        });
        fabAdd.addEventListener('click', () => {
            if (pend) { openPend(); return; }
            const wh = workHours[parseK(selKey).getDay()];
            let m = wh ? wh[0] : 9 * 60;
            if (selKey === todayKey()) m = Math.max(m, Math.ceil(nowMin() / SNAP) * SNAP);
            openAddModal(minToHHMM(Math.max(BOOK_S, Math.min(m, BOOK_E - SNAP))), { dayKey: selKey });
        });

        // ================= Докосване / мишка върху решетката =================
        // Кликове: блок -> детайли; заглавие на ден -> изглед Ден; иконата в ъгъла -> свий/разгъни;
        // клетка в месеца -> този ден.
        let suppressClickUntil = 0;
        scroll.addEventListener('click', (e) => {
            if (Date.now() < suppressClickUntil) return;
            if (e.target.closest('.sc-sel.is-pend')) { openPend(); return; }
            const rs = e.target.closest('[data-rest]');
            if (rs) { openRestModal((offs[rs.dataset.k] || []).find(x => x.kind === 'rest' && x.id === +rs.dataset.rest)); return; }
            const od = e.target.closest('[data-off]');
            if (od) { openRestModal((offs[od.dataset.k] || []).find(x => x.kind === 'off' && x.employeeId === +od.dataset.off)); return; }
            const bk = e.target.closest('.sc-bk');
            if (bk) { const b = (data[bk.dataset.k] || []).find(x => x.id === +bk.dataset.id); openBookingModal(b); return; }
            if (e.target.closest('.sc-corner')) { toggleCompress(); return; }
            const hd = e.target.closest('.sc-hd[data-k]');
            if (hd) { selKey = hd.dataset.k; setView('day'); return; }
            const mc = e.target.closest('.sc-mc');
            if (mc) { selKey = mc.dataset.k; setView('day'); }
        });

        const minAt = (col, clientY) => DAY_S + (clientY - col.getBoundingClientRect().top) / (HH0 * zoom) * 60;
        const durLabel = d => { const h = Math.floor(d / 60), m = d % 60; return h ? `${h} ч${m ? ` ${m} мин` : ''}` : `${m} мин`; };

        // Маркиране на период: задържане + плъзгане (телефон) / влачене (мишка).
        let sel = null;
        function beginSelect(col, clientY) {
            clearPend();
            const a = Math.max(BOOK_S, Math.min(BOOK_E - SNAP, Math.floor(minAt(col, clientY) / SNAP) * SNAP));
            const el = document.createElement('div');
            el.className = 'sc-sel';
            col.appendChild(el);
            sel = { col, a, s: a, e: Math.min(BOOK_E, a + 2 * SNAP), el };
            paintSel();
            root.classList.add('is-selecting');
            if (navigator.vibrate) try { navigator.vibrate(12); } catch (e) {}
        }
        function updateSelect(clientY) {
            if (!sel) return;
            const m = Math.max(BOOK_S, Math.min(BOOK_E, minAt(sel.col, clientY)));
            if (m >= sel.a) { sel.s = sel.a; sel.e = Math.max(sel.a + SNAP, Math.ceil(m / SNAP) * SNAP); }
            else { sel.s = Math.floor(m / SNAP) * SNAP; sel.e = sel.a + SNAP; }
            sel.e = Math.min(BOOK_E, sel.e);
            paintSel();
        }
        function paintSel() {
            const { s, e, el } = sel;
            el.style.top = pct(s);
            el.style.height = pctD(e - s);
            el.innerHTML = `<span>${minToHHMM(s)} – ${minToHHMM(e)}</span><small>${durLabel(e - s)}</small>`;
        }
        function clearSel() { if (sel) sel.el.remove(); sel = null; root.classList.remove('is-selecting'); cancelAnimationFrame(asRaf); asRaf = null; }
        function finishSelect() {
            if (!sel) return;
            const { col, s, e } = sel;
            root.classList.remove('is-selecting');
            cancelAnimationFrame(asRaf); asRaf = null;
            suppressClickUntil = Date.now() + 450;
            const el = sel.el; sel = null;
            // Маркираното остава на екрана: зеленото ✓ го запазва като „Запазено"
            // (зает час без клиент/процедура); докосване върху него или „+" -> пълния попъп.
            pend = { el, k: col.dataset.k, s, e, empId: col.dataset.emp ? +col.dataset.emp : undefined };
            el.classList.add('is-pend');
            el.insertAdjacentHTML('beforeend', `<em>✓ = запази · докосни за клиент</em>`);
            fabOk.hidden = false;
        }
        function clearPend() {
            if (pend) { pend.el.remove(); pend = null; }
            if (fabOk) fabOk.hidden = true;
        }
        // За кого е: колоната (Ден + всички) -> филтъра -> собствения график.
        const pendEmp = p => p.empId != null ? p.empId : (empFilter != null ? empFilter : (hasEmps() ? null : cfg.staffId));
        function openPend(preset) {
            if (!pend) return;
            const p = pend; pend = null; fabOk.hidden = true;
            p.el.classList.remove('is-pend');
            const em = p.el.querySelector('em'); if (em) em.remove();
            openAddModal(minToHHMM(p.s), { dayKey: p.k, dur: p.e - p.s, empId: p.empId, preset, onClose: () => p.el.remove() });
        }
        fabOk.addEventListener('click', async () => {
            if (!pend) return;
            const p = pend, emp = pendEmp(p);
            if (emp == null) { openPend('__resv'); return; }   // целият салон, седмица -> първо избор на специалист
            // Пояснение по избор (напр. „Почивам“) — вижда се върху блокчето в графика.
            const dd = parseK(p.k);
            noteModal({
                title: 'Запазено време',
                sub: `${WDNAMES[dd.getDay()]}, ${dd.getDate()} ${MON[dd.getMonth()].toLowerCase()} · ${minToHHMM(p.s)}–${minToHHMM(p.e)}`,
                saveLabel: 'Запази времето',
                onSave: async (note) => {
                    await window.API.post('/schedule/block', {
                        employeeId: emp, blockType: 'reserved', note,
                        startAt: `${p.k}T${minToHHMM(p.s)}:00`, endAt: `${p.k}T${minToHHMM(p.e)}:00`
                    });
                    if (pend === p) clearPend();
                    await load();
                }
            });
        });
        // Автоматичен скрол, докато пръстът е до ръба (за да се маркира и отвъд екрана).
        let asRaf = null, lastY = 0;
        function autoScroll() {
            asRaf = null;
            if (!sel) return;
            const r = scroll.getBoundingClientRect();
            let dy = 0;
            if (lastY > r.bottom - 56) dy = Math.min(16, (lastY - (r.bottom - 56)) / 3 + 2);
            else if (lastY < r.top + HEAD + 40) dy = -Math.min(16, (r.top + HEAD + 40 - lastY) / 3 + 2);
            if (!dy) return;
            scroll.scrollTop += dy;
            updateSelect(lastY);
            asRaf = requestAnimationFrame(autoScroll);
        }
        function tapAdd(col, clientY) {
            if (pend) { clearPend(); return; }   // докосване встрани -> отказ от маркираното
            const m = Math.max(BOOK_S, Math.min(BOOK_E - SNAP, Math.floor(minAt(col, clientY) / SNAP) * SNAP));
            openAddModal(minToHHMM(m), { dayKey: col.dataset.k, empId: col.dataset.emp ? +col.dataset.emp : undefined });
        }

        // Swipe настрани (само когато нищо не се скролва хоризонтално) -> смяна на период.
        const canSwipe = () => scroll.scrollWidth <= scroll.clientWidth + 2;
        const slideEl = () => scroll.firstElementChild;
        function commitSwipe(dx) {
            const s = slideEl();
            if (Math.abs(dx) > 60) {
                if (s) { s.style.transition = 'transform .15s ease-out, opacity .15s ease-out'; s.style.transform = `translateX(${dx < 0 ? -40 : 40}%)`; s.style.opacity = '0'; }
                setTimeout(() => shift(dx < 0 ? 1 : -1), 140);
            } else if (s) { s.style.transition = 'transform .18s ease-out'; s.style.transform = ''; s.style.opacity = ''; }
        }

        let lastScrollAt = 0;
        scroll.addEventListener('scroll', () => { lastScrollAt = Date.now(); }, { passive: true });

        // Safari: собствената щипка на браузъра се спира само тук.
        ['gesturestart', 'gesturechange', 'gestureend'].forEach(ev => root.addEventListener(ev, e => e.preventDefault(), { passive: false }));

        let t = null, lpTimer = null, lastTouchAt = 0;
        const d2 = ts => Math.hypot(ts[0].clientX - ts[1].clientX, ts[0].clientY - ts[1].clientY) || 1;
        scroll.addEventListener('touchstart', (e) => {
            lastTouchAt = Date.now();
            clearTimeout(lpTimer);
            if (e.touches.length >= 2) {
                clearSel();
                if (view === 'month') { t = null; return; }
                t = { mode: 'pinch', d0: d2(e.touches), z0: zoom };
                return;
            }
            const p = e.touches[0];
            const col = e.target.closest('.sc-col');
            const slide = slideEl(); if (slide) slide.style.transition = 'none';
            t = { mode: 'pending', x0: p.clientX, y0: p.clientY, dx: 0, col, t0: Date.now(), fling: Date.now() - lastScrollAt < 120 };
            if (col && canAdd() && !e.target.closest(ITEM_SEL))
                lpTimer = setTimeout(() => { if (t && t.mode === 'pending') { t.mode = 'select'; beginSelect(col, t.y0); } }, 380);
        }, { passive: true });

        scroll.addEventListener('touchmove', (e) => {
            if (!t) return;
            if (t.mode === 'pinch') {
                if (e.touches.length < 2) return;
                e.preventDefault();
                const [a, b] = e.touches;
                zoomAt(t.z0 * d2(e.touches) / t.d0, (a.clientX + b.clientX) / 2, (a.clientY + b.clientY) / 2);
                return;
            }
            const p = e.touches[0];
            if (t.mode === 'select') {
                e.preventDefault();
                lastY = p.clientY;
                updateSelect(p.clientY);
                if (!asRaf) asRaf = requestAnimationFrame(autoScroll);
                return;
            }
            const dx = p.clientX - t.x0, dy = p.clientY - t.y0;
            if (t.mode === 'pending') {
                if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
                clearTimeout(lpTimer);
                t.mode = (view !== 'month' && Math.abs(dx) > Math.abs(dy) * 1.3 && canSwipe()) ? 'swipe' : 'scroll';
            }
            if (t.mode === 'swipe') {
                e.preventDefault();
                t.dx = dx;
                const s = slideEl();
                if (s) { s.style.transform = `translateX(${dx.toFixed(0)}px)`; s.style.opacity = String(Math.max(.4, 1 - Math.abs(dx) / 700)); }
            }
        }, { passive: false });

        scroll.addEventListener('touchend', (e) => {
            lastTouchAt = Date.now();
            clearTimeout(lpTimer);
            if (!t) return;
            if (t.mode === 'pinch') { if (!e.touches.length) { flushZoom(); saveZoom(); t = null; } return; }
            if (e.touches.length) return;
            const was = t; t = null;
            if (was.mode === 'select') finishSelect();
            else if (was.mode === 'swipe') commitSwipe(was.dx);
            else if (was.mode === 'pending' && was.col && !was.fling && canAdd() && !e.target.closest(ITEM_SEL)) {
                // Кратко докосване на празно място -> нов час в този момент.
                suppressClickUntil = Date.now() + 450;
                tapAdd(was.col, was.y0);
            }
        });
        scroll.addEventListener('touchcancel', () => {
            clearTimeout(lpTimer);
            if (t && t.mode === 'swipe') commitSwipe(0);
            clearSel(); t = null;
        });

        // Мишка: влачене надолу по празно място = маркиране; клик = нов час.
        let mSel = null;
        scroll.addEventListener('mousedown', (e) => {
            if (e.button !== 0 || Date.now() - lastTouchAt < 800) return;
            const col = e.target.closest('.sc-col');
            if (!col || e.target.closest(ITEM_SEL) || !canAdd()) return;
            e.preventDefault();
            mSel = { col, y0: e.clientY, moved: false };
        });
        window.addEventListener('mousemove', (e) => {
            if (!mSel) return;
            if (!mSel.moved) {
                if (Math.abs(e.clientY - mSel.y0) < 5) return;
                mSel.moved = true; beginSelect(mSel.col, mSel.y0);
            }
            lastY = e.clientY;
            updateSelect(e.clientY);
            if (!asRaf) asRaf = requestAnimationFrame(autoScroll);
        });
        window.addEventListener('mouseup', () => {
            if (!mSel) return;
            const m = mSel; mSel = null;
            if (m.moved) finishSelect();
            else { suppressClickUntil = Date.now() + 300; tapAdd(m.col, m.y0); }
        });

        // Десктоп: Ctrl + колелце (и щипка на тъчпада) = мащаб.
        // Колелцето на мишката дава ~100 на „щрак“ (преди = ×2.7 наведнъж), тъчпадът — малки
        // стойности. Нормализираме и ограничаваме -> ~×1.3 на щрак, плавно при тъчпад.
        scroll.addEventListener('wheel', (e) => {
            if (!e.ctrlKey || view === 'month') return;
            e.preventDefault();
            let d = e.deltaY * (e.deltaMode === 1 ? 16 : (e.deltaMode === 2 ? 400 : 1));
            d = Math.max(-60, Math.min(60, d));
            zoomAt(pendingZoom() * Math.exp(-d * 0.0045), e.clientX, e.clientY);
            clearTimeout(scroll._wz); scroll._wz = setTimeout(() => { saveZoom(); paintZoomVal(); }, 200);
        }, { passive: false });

        // Бутони − / + (компютър) и Ctrl + / Ctrl − / Ctrl 0 върху графика (вместо мащаба на браузъра).
        const zoomVal = root.querySelector('.sc-zoom__v');
        function paintZoomVal() { if (zoomVal) zoomVal.textContent = Math.round(zoom / Z_DEF * 100) + '%'; }
        const zoomStep = f => { if (view !== 'month') tweenZoom(clampZoom(zoom * f), paintZoomVal); };
        root.querySelector('.sc-zoom-in').addEventListener('click', () => zoomStep(1.2));
        root.querySelector('.sc-zoom-out').addEventListener('click', () => zoomStep(1 / 1.2));
        zoomVal.addEventListener('click', () => { if (view !== 'month') tweenZoom(Z_DEF, paintZoomVal); });
        paintZoomVal();
        const onKeyZoom = (e) => {
            if (!document.body.contains(root)) { document.removeEventListener('keydown', onKeyZoom); return; }
            if (!(e.ctrlKey || e.metaKey) || e.altKey || view === 'month' || !root.offsetParent) return;
            if (document.querySelector('.cal-modal-backdrop')) return;
            const k = e.key;
            if (k === '+' || k === '=') { e.preventDefault(); zoomStep(1.2); }
            else if (k === '-' || k === '_') { e.preventDefault(); zoomStep(1 / 1.2); }
            else if (k === '0') { e.preventDefault(); tweenZoom(Z_DEF, paintZoomVal); }
        };
        document.addEventListener('keydown', onKeyZoom);

        // Червената линия „сега" се мести сама всяка минута.
        let dayAtMount = todayKey();
        const nowTimer = setInterval(() => {
            if (!document.body.contains(root)) { clearInterval(nowTimer); return; }
            if (todayKey() !== dayAtMount) { dayAtMount = todayKey(); render(); return; }
            root.querySelectorAll('.sc-now').forEach(el => { const m = nowMin(); el.style.top = pct(m); el.style.display = m >= DAY_S && m <= DAY_E ? '' : 'none'; });
        }, 60000);

        // Бързи пояснения за „Запазено“ / почивка.
        const NOTE_CHIPS = ['Почивам', 'Обедна почивка', 'Лични ангажименти', 'Лекар', 'Обучение'];
        const chipsHtml = () => `<div class="ad-chips">${NOTE_CHIPS.map(t => `<button type="button" class="ad-chip">${esc(t)}</button>`).join('')}</div>`;
        function wireChips(box, input) {
            box.querySelectorAll('.ad-chip').forEach(c => c.addEventListener('click', () => { input.value = c.textContent; input.focus(); }));
        }
        // Попъп: пояснение по избор -> onSave(note | null).
        function noteModal({ title, sub, value, saveLabel, onSave }) {
            document.querySelectorAll('.cal-modal-backdrop').forEach(x => x.remove());
            const backdrop = document.createElement('div');
            backdrop.className = 'cal-modal-backdrop';
            backdrop.innerHTML = `
                <div class="cal-modal">
                    <button class="cal-modal__close" aria-label="Затвори">×</button>
                    <div class="cal-modal__title">${esc(title)}</div>
                    ${sub ? `<div class="cal-modal__meta hint">${esc(sub)}</div>` : ''}
                    <label class="field" style="margin-top:.9rem"><span class="ad-lbl">Пояснение <small>(по избор)</small></span>
                        <input class="input nm-note" type="text" maxlength="200" placeholder="напр. Почивам" value="${esc(value || '')}"></label>
                    ${chipsHtml()}
                    <div class="cal-modal__actions" style="margin-top:1rem"><button class="btn btn--primary nm-save">${esc(saveLabel || 'Запази')}</button></div>
                    <div class="md-msg" style="margin-top:.8rem"></div>
                </div>`;
            document.body.appendChild(backdrop);
            const close = () => backdrop.remove();
            backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
            backdrop.querySelector('.cal-modal__close').addEventListener('click', close);
            const inp = backdrop.querySelector('.nm-note'), btn = backdrop.querySelector('.nm-save');
            wireChips(backdrop, inp);
            const save = async () => {
                btn.disabled = true;
                try { await onSave(inp.value.trim() || null); close(); }
                catch (err) { backdrop.querySelector('.md-msg').innerHTML = `<div class="alert alert--err">${esc(err.message)}</div>`; btn.disabled = false; }
            };
            btn.addEventListener('click', save);
            inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
            if (matchMedia('(hover: hover) and (pointer: fine)').matches) inp.focus();
        }

        // Попъп за добавяне на час (клик на празно място / маркиран период в графика).
        // В „Целият салон" има и избор на специалист (за кого е часът).
        // В списъка с услуги има и „Почивка" (блокира време) и „Почивен ден" (цял ден).
        // opts: { dayKey, dur (маркирани минути), empId (от колоната), onClose }
        const REST = REST_MIN; // стандартна почивка след процедура (като WorkingHours.RestBufferMinutes в backend-а)
        function openAddModal(hhmm, opts = {}) {
            document.querySelectorAll('.cal-modal-backdrop').forEach(x => x.remove());
            const pickEmp = !!(cfg.showEmployee && cfg.employees && cfg.employees.length && cfg.servicesFor);
            const dayKey = opts.dayKey || selKey;
            const dd = parseK(dayKey);
            const presetEmp = opts.empId != null ? opts.empId : empFilter;
            const ED = opts.edit || null;   // редакция на съществуващ ръчен час
            // И в чужд график с достъп (Анелия -> Радина) — всичко: „Запазено“, почивка, почивен ден.
            const SPECIAL = ED ? '' : canRest()
                ? `<option value="__resv">Запазено (без клиент)</option><option value="__rest">Почивка</option><option value="__off">Почивен ден (цял ден)</option>`
                : '';

            let timeOpts = '';
            for (let mm = BOOK_S; mm < BOOK_E; mm += 15) { const v = minToHHMM(mm); timeOpts += `<option value="${v}"${v === hhmm ? ' selected' : ''}>${v}</option>`; }
            if (!timeOpts.includes(`value="${hhmm}"`)) timeOpts = `<option value="${hhmm}" selected>${hhmm}</option>` + timeOpts;
            const empOpts = pickEmp ? cfg.employees.map(e => `<option value="${e.id}"${presetEmp === e.id ? ' selected' : ''}>${esc(e.name)}</option>`).join('') : '';
            const staticSvc = pickEmp ? '' : (cfg.services || []).map(s => `<option value="${s.serviceId}">${esc(s.serviceName)} · ${s.durationMinutes} мин</option>`).join('');
            const REST_OPTS = [0, 5, 10, 15, 20, 30, 45, 60];

            const backdrop = document.createElement('div');
            backdrop.className = 'cal-modal-backdrop';
            backdrop.innerHTML = `
                <div class="cal-modal cal-modal--add">
                    <button class="cal-modal__close" aria-label="Затвори">×</button>
                    <div class="ad-title" style="font-weight:800;font-size:1.15rem">${ED ? 'Редактирай час' : 'Нов час'}</div>
                    <div class="hint ad-sub" style="margin:.15rem 0 .85rem">${WDNAMES[dd.getDay()]}, ${dd.getDate()} ${MON[dd.getMonth()].toLowerCase()}${opts.dur ? ` · ${hhmm}–${minToHHMM(Math.min(24 * 60, hhmmToMin(hhmm) + opts.dur))}` : ''}</div>
                    <div class="ad-form">
                        ${pickEmp ? `<label class="field"><span class="ad-lbl">Специалист</span>
                            <select class="select ad-emp">${empOpts}</select></label>` : ''}
                        <label class="field"><span class="ad-lbl">Услуга</span>
                            <select class="select ad-svc">${pickEmp ? '<option value="">Избери специалист…</option>' : (staticSvc || '<option value="">Няма зададени услуги</option>') + SPECIAL}</select></label>
                        ${ED ? `<label class="field"><span class="ad-lbl">Дата</span>
                            <input class="input ad-date" type="date" value="${dayKey}" max="${(() => { const m = new Date(); m.setMonth(m.getMonth() + 6); return `${m.getFullYear()}-${pad(m.getMonth() + 1)}-${pad(m.getDate())}`; })()}"></label>` : ''}
                        <div class="ad-pair ad-pair--time ad-row-time">
                            <label class="field"><span class="ad-lbl">Начален час</span>
                                <select class="select ad-time">${timeOpts}</select></label>
                            <label class="field ad-f-dur"><span class="ad-lbl ad-dur-lbl">Продължителност</span>
                                <select class="select ad-dur"></select></label>
                            <div class="field ad-f-hm"><span class="ad-lbl" title="Колко време да заеме часът в графика. Удължи го, ако искаш почивка след клиента.">Времетраене</span>
                                <div class="ad-hm">
                                    <select class="ad-h" aria-label="Часове"></select>
                                    <span class="ad-hm__sep"></span>
                                    <select class="ad-m" aria-label="Минути"></select>
                                </div></div>
                        </div>
                        <div class="ad-row-price">
                            <label class="field"><span class="ad-lbl">Цена</span>
                                <span class="ad-eur"><input class="input ad-price" type="number" min="0" step="0.5" inputmode="decimal"><i>€</i></span></label>
                        </div>
                        <div class="ad-extras"></div>
                        <button type="button" class="btn btn--ghost ad-add-x">+ Още процедура за същия клиент</button>
                        <div class="ad-row-note">
                            <label class="field"><span class="ad-lbl">Пояснение <small>(по избор)</small></span>
                                <input class="input ad-bnote" type="text" maxlength="200" placeholder="напр. Почивам"></label>
                            ${chipsHtml()}
                        </div>
                        <div class="ad-row-rest"><div class="ad-sum"></div></div>
                        <div class="ad-off-note hint" style="display:none">Целият ден ще е почивен — никой няма да може да си запише час. Отменя се с клик върху деня в графика.</div>
                        <div class="ad-pair ad-row-client">
                            <label class="field"><span class="ad-lbl">Име на клиента</span>
                                <input class="input ad-name" type="text" placeholder="напр. Мария" autocomplete="off" autocorrect="off" spellcheck="false" autocapitalize="words"></label>
                            <label class="field"><span class="ad-lbl">Телефон <small>(по избор)</small></span>
                                <input class="input ad-phone" type="tel" placeholder="+359…" autocomplete="off"></label>
                        </div>
                        <div class="ad-known hint" hidden></div>
                        <button class="btn btn--primary ad-save">${ED ? 'Запази промените' : 'Запиши часа'}</button>
                        <div class="ad-msg"></div>
                    </div>
                </div>`;
            document.body.appendChild(backdrop);
            const close = () => { backdrop.remove(); if (opts.onClose) opts.onClose(); };
            backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
            backdrop.querySelector('.cal-modal__close').addEventListener('click', close);

            const $ = sel => backdrop.querySelector(sel);
            if (cfg.hidePrices) backdrop.classList.add('is-noprice');
            const subOrig = ($('.ad-sub') || {}).textContent || '';
            const empSel = $('.ad-emp'), svcSel = $('.ad-svc'), timeSel = $('.ad-time');
            const durSel = $('.ad-dur'), hSel = $('.ad-h'), mSel = $('.ad-m'), sumEl = $('.ad-sum');
            const saveBtn = $('.ad-save'), msg = $('.ad-msg');
            const show = (sel, on) => { $(sel).style.display = on ? '' : 'none'; };
            const mode = () => svcSel.value === '__rest' ? 'rest' : (svcSel.value === '__resv' ? 'resv' : (svcSel.value === '__off' ? 'off' : 'svc'));
            const isBlk = md => md === 'rest' || md === 'resv';
            const whEnd = () => { const wh = workHours[dd.getDay()]; return wh ? wh[1] : 1110; };
            const numOpts = (vals, def, label) => [...new Set(vals)].sort((a, b) => a - b)
                .map(m => `<option value="${m}"${m === def ? ' selected' : ''}>${label(m)}</option>`).join('');

            let edDurUsed = false;
            // Редакция: избира услугата на часа (ако вече я няма в списъка — добавя я, за да не се загуби).
            function pickEditSvc() {
                const id = String(ED.serviceId);
                if (![...svcSel.options].some(o => o.value === id)) {
                    svcSel.insertAdjacentHTML('afterbegin', `<option value="${id}">${esc(ED.serviceName)}</option>`);
                }
                svcSel.value = id;
            }
            // Карта service_id -> времетраене на процедурата.
            let svcDur = {}, svcPrice = {};
            (cfg.services || []).forEach(s => { svcDur[s.serviceId] = s.durationMinutes; svcPrice[s.serviceId] = s.price; });
            const fmtP = v => (v == null || v === '' || isNaN(+v)) ? '' : String(Math.round(+v * 100) / 100);
            const priceEl = $('.ad-price'), extrasEl = $('.ad-extras'), addXBtn = $('.ad-add-x');
            wireChips(backdrop, $('.ad-bnote'));

            // ---- Още процедури за същия клиент (записват се една след друга) ----
            const svcOptsHtml = () => [...svcSel.options].filter(o => o.value && !o.value.startsWith('__'))
                .map(o => `<option value="${o.value}">${esc(o.text)}</option>`).join('');
            const xRows = () => [...extrasEl.querySelectorAll('.ad-x')];
            // Редакция: времето на часа преди първата добавена процедура (към него се добавят новите).
            let edBase = null;
            const xStd = () => xRows().reduce((s, r) => s + (svcDur[+r.querySelector('.ad-x-svc').value] || 0), 0);
            const fitX = () => {
                if (!ED) return setHM(Math.max(stdTotal(), opts0()));
                if (edBase == null) edBase = hmVal();
                setHM(edBase + xStd());
            };
            const stdTotal = () => (svcDur[+svcSel.value] || 0) + xRows().reduce((s, r) => s + (svcDur[+r.querySelector('.ad-x-svc').value] || 0), 0);
            const numP = el => { const v = String(el.value).trim().replace(',', '.'); return v === '' ? null : +v; };
            function renumberX() { xRows().forEach((r, i) => { r.querySelector('.ad-x-n').textContent = `Процедура ${i + 2}`; }); }
            function addExtra() {
                const oh = svcOptsHtml();
                if (!oh) return;
                if (ED && edBase == null) edBase = hmVal();
                const row = document.createElement('div');
                row.className = 'ad-x';
                row.innerHTML = `<div class="ad-x__top"><span class="ad-lbl ad-x-n"></span><button type="button" class="ad-x__del" aria-label="Махни процедурата">×</button></div>
                    <select class="select ad-x-svc"><option value="">Избери процедура…</option>${oh}</select>
                    <label class="field ad-x__price"><span class="ad-lbl">Цена</span>
                        <span class="ad-eur"><input class="input ad-x-price" type="number" min="0" step="0.5" inputmode="decimal"><i>€</i></span></label>`;
                extrasEl.appendChild(row);
                const sel = row.querySelector('.ad-x-svc'), pr = row.querySelector('.ad-x-price');
                const onSvc = () => { pr.value = fmtP(svcPrice[+sel.value]); fitX(); paintSum(); };
                sel.addEventListener('change', onSvc);
                pr.addEventListener('input', paintSum);
                row.querySelector('.ad-x__del').addEventListener('click', () => { row.remove(); renumberX(); fitX(); paintSum(); });
                svcPicker(sel, () => (empSel ? empSel.value : cfg.staffId));
                renumberX();
                const b = row.querySelector('.svp-btn'); if (b) b.click();
            }
            const opts0 = () => (ED ? 0 : (opts.dur || 0));
            if (addXBtn) addXBtn.addEventListener('click', addExtra);
            priceEl.addEventListener('input', paintSum);

            // Часове 0–8, минути през 5.
            hSel.innerHTML = Array.from({ length: 9 }, (_, h) => `<option value="${h}">${h} ч</option>`).join('');
            mSel.innerHTML = Array.from({ length: 12 }, (_, i) => `<option value="${i * 5}">${String(i * 5).padStart(2, '0')} мин</option>`).join('');
            const hmVal = () => (+hSel.value || 0) * 60 + (+mSel.value || 0);
            function setHM(total) {
                total = Math.max(5, Math.min(8 * 60, Math.round(total / 5) * 5));
                hSel.value = String(Math.floor(total / 60));
                mSel.value = String(total % 60);
            }

            function fillDur() {
                const md = mode();
                if (isBlk(md)) {
                    const def = opts.dur || 60;
                    durSel.innerHTML = numOpts([15, 30, 45, 60, 90, 120, 180, 240, def], def,
                        m => durLabel(m) + (m === opts.dur ? ' · маркирано' : '')) + `<option value="end">до края на деня</option>`;
                } else if (md === 'svc') {
                    // Времетраене = стандартното за услугата (или маркирания период).
                    // Специалистът може да го промени свободно — така си прави и почивката.
                    // По подразбиране: времето на процедурата. Ако в графика е маркиран
                    // по-дълъг период (напр. с почивка) — остава маркираното.
                    // + REST (10 мин почивка) по подразбиране — като онлайн записването:
                    // процедура 1:30 -> часът заема 1:40 в графика.
                    const std = stdTotal() ? stdTotal() + REST : 30;
                    // Редакция: първия път — текущото времетраене и цена на часа; при смяна на услугата — нейните.
                    if (ED && !edDurUsed) { edDurUsed = true; setHM(opts.dur || std); priceEl.value = fmtP(ED.priceSnapshot); }
                    else { setHM(ED ? std : Math.max(std, opts.dur || 0)); priceEl.value = fmtP(svcPrice[+svcSel.value]); if (ED && edBase != null) edBase = hmVal() - xStd(); }
                }
                paintMode();
            }
            function paintMode() {
                const md = mode();
                show('.ad-row-time', md !== 'off');
                show('.ad-row-rest', md === 'svc');
                show('.ad-f-dur', isBlk(md));
                show('.ad-f-hm', md === 'svc');
                show('.ad-row-client', md === 'svc');
                show('.ad-row-price', md === 'svc' && !cfg.hidePrices);
                show('.ad-extras', md === 'svc');
                if (addXBtn) addXBtn.style.display = md === 'svc' ? '' : 'none';
                show('.ad-row-note', isBlk(md));
                if (md !== 'svc') $('.ad-known').hidden = true;
                show('.ad-off-note', md === 'off');
                $('.ad-dur-lbl').textContent = isBlk(md) ? 'Продължителност' : 'Процедура';
                $('.ad-title').textContent = md === 'svc' ? (ED ? 'Редактирай час' : 'Нов час') : (md === 'rest' ? 'Почивка' : (md === 'resv' ? 'Запазено време' : 'Почивен ден'));
                saveBtn.textContent = md === 'svc' ? (ED ? 'Запази промените' : 'Запиши часа') : (md === 'rest' ? 'Запази почивката' : (md === 'resv' ? 'Запази времето' : 'Маркирай почивен ден'));
                paintSum();
            }
            // „Готово в 09:45 · следващ час от 10:00"
            function paintSum() {
                if (mode() !== 'svc') { sumEl.innerHTML = ''; const sb = $('.ad-sub'); if (sb) sb.textContent = subOrig; return; }
                const st = hhmmToMin(timeSel.value), total = hmVal();
                const end = minToHHMM(Math.min(1440, st + total));
                const std = stdTotal();
                const diff = total - std;
                const note = !std || diff === 0 ? 'стандартно'
                    : (diff > 0 ? `+${durLabel(diff)} почивка` : `−${durLabel(-diff)} от стандартното`);
                const nX = xRows().length;
                const sumP = [priceEl, ...xRows().map(r => r.querySelector('.ad-x-price'))].reduce((s, el) => s + (numP(el) || 0), 0);
                sumEl.innerHTML = `<span>${timeSel.value} – <b>${end}</b></span><span>${durLabel(total)} · <i class="ad-sum__note${diff < 0 ? ' is-short' : ''}">${note}</i></span>`
                    + (nX ? `<span class="ad-sum__tot">${nX + 1} процедури · общо <b>${fmtP(sumP)} €</b></span>` : '');
                // Подзаглавието горе следва реалния край на часа.
                const sub = $('.ad-sub');
                if (sub) sub.textContent = `${WDNAMES[dd.getDay()]}, ${dd.getDate()} ${MON[dd.getMonth()].toLowerCase()} · ${timeSel.value}–${end}`;
            }

            async function loadSvc(empId) {
                svcSel.innerHTML = `<option value="">Зареждане…</option>`;
                try {
                    const list = await cfg.servicesFor(empId);
                    svcDur = {}; svcPrice = {};
                    (list || []).forEach(s => { svcDur[s.serviceId] = s.durationMinutes; svcPrice[s.serviceId] = s.price; });
                    extrasEl.innerHTML = '';   // друга специалистка -> добавените процедури не важат
                    svcSel.innerHTML = ((list && list.length)
                        ? list.map(s => `<option value="${s.serviceId}">${esc(s.serviceName)} · ${s.durationMinutes} мин</option>`).join('')
                        : `<option value="">Няма зададени услуги</option>`) + SPECIAL;
                    if (opts.preset && SPECIAL) svcSel.value = opts.preset;
                    else if (!ED) selectLastSvc(svcSel, empId);   // последно избраната процедура
                    if (ED && (!empSel || +empSel.value === ED.employeeId)) pickEditSvc();
                    fillDur();
                } catch (e) { svcSel.innerHTML = `<option value="">Грешка при зареждане</option>` + SPECIAL; fillDur(); }
            }
            // Познат клиент по телефона -> подсказка + попълва името (ако е празно).
            const phoneEl = $('.ad-phone'), nameEl = $('.ad-name'), knownEl = $('.ad-known');
            let lkT = null, lkSeq = 0;
            // Избрана от подсказките клиентка: ключът ѝ (u12 = профил) отива към сървъра,
            // за да влезе часът в профила ѝ дори без/с друг телефон.
            let picked = null;   // { key, name, phone, hasAccount }
            const digits = v => String(v || '').replace(/\D/g, '').replace(/^359/, '0');
            function paintPicked() {
                knownEl.classList.toggle('is-prof', !!(picked && picked.hasAccount));
                if (!picked || !picked.hasAccount) return false;
                knownEl.innerHTML = `${profBadge('Има профил')}<span><b>${esc(picked.name)}</b> — часът ще се появи в профила ѝ, в „Предстоящи часове“.</span>`
                    + (picked.noShow ? ` <span style="color:#D9534F;font-weight:700">⚠ ${picked.noShow}× не се яви</span>` : '');
                knownEl.hidden = false;
                return true;
            }
            // Сменено име И телефон спрямо избраната -> вече е друг човек, връзката пада.
            function checkPicked() {
                if (!picked) return;
                const sameName = nameEl.value.trim().toLowerCase() === picked.name.trim().toLowerCase();
                const samePhone = picked.phone && digits(phoneEl.value) === digits(picked.phone);
                if (!nameEl.value.trim() || (!sameName && !samePhone) || (picked.phone && digits(phoneEl.value) && !samePhone)) {
                    picked = null; knownEl.classList.remove('is-prof'); knownEl.hidden = true;
                    acMute = true; phoneEl.dispatchEvent(new Event('input')); acMute = false;
                }
            }
            phoneEl.addEventListener('input', () => {
                clearTimeout(lkT);
                if (paintPicked()) return;
                const v = phoneEl.value.replace(/\D/g, '');
                if (v.length < 9) { knownEl.hidden = true; return; }
                lkT = setTimeout(async () => {
                    const my = ++lkSeq;
                    try {
                        const r = await window.API.get(`/clients/lookup?phone=${encodeURIComponent(phoneEl.value.trim())}`);
                        if (my !== lkSeq) return;
                        if (paintPicked()) return;
                        if (!r) { knownEl.hidden = true; return; }
                        if (!nameEl.value.trim()) nameEl.value = r.name;
                        knownEl.classList.toggle('is-prof', !!r.hasAccount);
                        knownEl.innerHTML = (r.hasAccount
                                ? `${profBadge('Има профил')}<span><b>${esc(r.name)}</b> — часът ще се появи в профила ѝ · ${r.total} ${r.total === 1 ? 'час' : 'часа'}</span>`
                                : `<b>${esc(r.name)}</b> · познат клиент · ${r.total} ${r.total === 1 ? 'час' : 'часа'}`)
                            + (r.noShow ? ` <span style="color:#D9534F;font-weight:700">⚠ ${r.noShow}× не се яви</span>` : '');
                        knownEl.hidden = false;
                    } catch (e) { knownEl.hidden = true; }
                }, 350);
            });
            // ---- Подсказки за клиент: пишеш „Мар“ или част от телефона -> „Мария Димитрова · 0888…“ ----
            const acEl = document.createElement('div');
            acEl.className = 'ad-ac'; acEl.hidden = true;
            $('.ad-row-client').appendChild(acEl);
            // Всички съвпадения (до 100), по един ред, без вътрешен скрол — скролва се самата форма
            // (на iPhone списък със собствен скрол не мърда при отворена клавиатура).
            const AC_MAX = 100;
            let acSeq = 0, acList = [], acAct = -1, acMute = false, acQ = null, acMore = 0;
            const acHide = () => { acEl.hidden = true; acList = []; acAct = -1; acQ = null; };
            const ph0 = d => d.startsWith('359') ? '0' + d.slice(3) : d;   // +359 888… == 0888…
            // 0 — името започва с написаното, 1 — някоя дума от името, 2 — съдържа го, 3 — по телефона.
            function acRank(c, q, qd) {
                if (c._n.startsWith(q)) return 0;
                if (c._w.some(w => w.startsWith(q))) return 1;
                if (q.length >= 3 && c._n.includes(q)) return 2;
                if (qd.length >= 2 && c._d && (c._d.includes(qd) || ph0(c._d).includes(ph0(qd)))) return 3;
                return -1;
            }
            function acPaint(scroll) {
                if (!acList.length) { acHide(); return; }
                acEl.innerHTML = acList.map((c, i) => `<button type="button" class="ad-ac__it${i === acAct ? ' is-act' : ''}${c.hasAccount ? ' is-prof' : ''}" data-i="${i}"${c.hasAccount ? ' title="Има профил в сайта"' : ''}>
                    ${c.hasAccount ? `<i class="ad-ac__ico">${PROF_ICO}</i>` : ''}<b>${esc(c.name)}</b><span>${esc(c.phone || 'без телефон')}${c.noShow ? ` · <em>⚠ ${c.noShow}× не се яви</em>` : ''}</span></button>`).join('')
                    + (acMore ? `<div class="ad-ac__more">още ${acMore} — пиши още от името</div>` : '');
                const wasHidden = acEl.hidden;
                acEl.hidden = false;
                if (wasHidden || scroll) acEl.scrollIntoView({ block: 'nearest' });
            }
            function acFilter(list, raw, src) {
                const q = nameKey(raw), qd = raw.replace(/\D/g, '');
                const byPhone = src === phoneEl || (qd && qd.length === raw.replace(/[\s+()-]/g, '').length);
                const out = [];
                for (const c of list) {
                    const r = byPhone ? (qd.length >= 2 && c._d && (c._d.includes(qd) || ph0(c._d).includes(ph0(qd))) ? 3 : -1) : acRank(c, q, qd);
                    if (r >= 0) out.push([r, c]);
                }
                out.sort((a, b) => a[0] - b[0] || (b[1].hasAccount ? 1 : 0) - (a[1].hasAccount ? 1 : 0) || a[1].name.localeCompare(b[1].name, 'bg'));
                acMore = Math.max(0, out.length - AC_MAX);
                return out.slice(0, AC_MAX).map(x => x[1]);
            }
            // Търси на място в заредения списък — без чакане на сървъра.
            async function acQuery(src) {
                if (acMute || src.readOnly) return;
                const raw = src.value.trim();
                if (!raw || (src === phoneEl && raw.replace(/\D/g, '').length < 2)) { acHide(); return; }
                if (raw === acQ && !acEl.hidden) return;   // keyup/compositionend след input — нищо ново
                acQ = raw;
                const my = ++acSeq;
                let list = CL.list;
                if (!list) {
                    try { list = await clientsLoad(); }
                    catch (e) {   // списъкът не се зареди -> търсене в сървъра
                        try {
                            const r = await window.API.get(`/clients?q=${encodeURIComponent(raw)}`);
                            list = clPrep(r);
                        } catch (e2) { list = []; }
                    }
                    if (my !== acSeq || document.activeElement !== src) return;
                }
                acList = acFilter(list, src.value.trim(), src);
                acAct = -1; acPaint();
            }
            clientsLoad(true).catch(() => {});   // зарежда/опреснява списъка още докато формата се отваря
            function acPick(c) {
                if (!c) return;
                nameEl.value = c.name;
                picked = { key: c.key, name: c.name, phone: c.phone || '', hasAccount: !!c.hasAccount, noShow: c.noShow || 0 };
                acHide();
                paintPicked();
                if (c.phone) {
                    phoneEl.value = c.phone;
                    acMute = true; phoneEl.dispatchEvent(new Event('input')); acMute = false;   // -> „познат клиент“ отдолу
                }
            }
            // Мишка -> избира веднага (без да губи фокуса). Пръст -> само при докосване без плъзгане,
            // иначе списъкът/прозорецът се скролват нормално.
            let acTouch = null;
            acEl.addEventListener('pointerdown', e => {
                const b = e.target.closest('.ad-ac__it'); if (!b) return;
                if (e.pointerType === 'mouse') { e.preventDefault(); acPick(acList[+b.dataset.i]); return; }
                acTouch = { b, x: e.clientX, y: e.clientY };
            });
            acEl.addEventListener('pointermove', e => {
                if (acTouch && Math.hypot(e.clientX - acTouch.x, e.clientY - acTouch.y) > 8) acTouch = null;
            });
            acEl.addEventListener('pointercancel', () => { acTouch = null; });   // браузърът пое скрола
            acEl.addEventListener('pointerup', e => {
                const t = acTouch; acTouch = null;
                if (!t || e.target.closest('.ad-ac__it') !== t.b) return;
                e.preventDefault(); acPick(acList[+t.b.dataset.i]);
            });
            [nameEl, phoneEl].forEach(el => {
                // iOS понякога не праща „input“ при предложенията на клавиатурата -> и keyup/compositionend.
                ['input', 'keyup', 'compositionend'].forEach(ev => el.addEventListener(ev, e => {
                    if (e.type === 'keyup' && /^(Arrow|Enter|Escape|Tab)/.test(e.key)) return;
                    if (e.type === 'input' && !acMute) checkPicked();
                    acQuery(el);
                }));
                el.addEventListener('focus', () => { acQ = null; acQuery(el); });
                el.addEventListener('blur', () => setTimeout(() => {
                    if (document.activeElement !== nameEl && document.activeElement !== phoneEl) acHide();
                }, 200));
                el.addEventListener('keydown', e => {
                    if (acEl.hidden || !acList.length) return;
                    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                        e.preventDefault();
                        acAct = (acAct + (e.key === 'ArrowDown' ? 1 : -1) + acList.length) % acList.length; acPaint(true);
                        const it = acEl.children[acAct]; if (it) it.scrollIntoView({ block: 'nearest' });
                    } else if (e.key === 'Enter' && acAct >= 0) { e.preventDefault(); acPick(acList[acAct]); }
                    else if (e.key === 'Escape') { e.stopPropagation(); acHide(); }
                });
            });

            svcSel.addEventListener('change', fillDur);
            [timeSel, durSel, hSel, mSel].forEach(x => x.addEventListener('change', paintSum));
            if (!empSel && !ED && !(opts.preset && SPECIAL)) selectLastSvc(svcSel, cfg.staffId);   // последно избраната процедура
            svcPicker(svcSel, () => (empSel ? empSel.value : cfg.staffId));
            if (empSel) { empSel.addEventListener('change', () => loadSvc(+empSel.value)); loadSvc(+empSel.value); }
            else { if (opts.preset && SPECIAL) svcSel.value = opts.preset; if (ED) pickEditSvc(); fillDur(); } // единичен специалист: услугите вече са налични
            if (ED) { nameEl.value = ED.clientName || ''; phoneEl.value = ED.clientPhone || ''; }
            if (ED && !ED.isOnline && ED.clientId > 0) {
                picked = { key: 'u' + ED.clientId, name: ED.clientName || '', phone: ED.clientPhone || '', hasAccount: true, noShow: 0 };
                paintPicked();
            }
            // Онлайн час: клиентът е от профила си — име и телефон не се сменят тук.
            if (ED && ED.isOnline) {
                [nameEl, phoneEl].forEach(el => { el.readOnly = true; el.style.opacity = '.7'; });
                knownEl.hidden = false;
                knownEl.textContent = 'Онлайн час — клиентът е от профила си. Може да смениш процедурата, часа, времетраенето и цената.';
            }

            saveBtn.addEventListener('click', async () => {
                const employeeId = empSel ? +empSel.value : cfg.staffId;
                const md = mode();
                const dateVal = ED ? ($('.ad-date').value || dayKey) : dayKey;
                const startAt = `${dateVal}T${timeSel.value}:00`;
                const err = t => { msg.innerHTML = `<div class="alert alert--err">${esc(t)}</div>`; };
                if (pickEmp && !employeeId) return err('Избери специалист.');

                let run;
                if (md === 'off') {
                    run = () => window.API.put('/schedule/override', { employeeId, date: dayKey, isOff: true });
                } else if (isBlk(md)) {
                    const dur = durSel.value === 'end' ? whEnd() - hhmmToMin(timeSel.value) : +durSel.value;
                    if (!(dur > 0)) return err('Началният час е след края на работния ден.');
                    const note = $('.ad-bnote').value.trim() || null;
                    run = () => window.API.post('/schedule/block', { employeeId, blockType: md === 'resv' ? 'reserved' : 'rest', note, startAt, endAt: addMinIso(startAt, Math.min(dur, 1440 - hhmmToMin(timeSel.value))) });
                } else {
                    const dto = {
                        employeeId,
                        serviceId: +svcSel.value,
                        startAt,
                        procedureMinutes: hmVal(),
                        restMinutes: 0, // почивката е включена във времетраенето
                        guestName: $('.ad-name').value.trim(),
                        guestPhone: $('.ad-phone').value.trim() || null,
                        clientKey: picked ? picked.key : null,
                        note: null
                    };
                    if (!dto.serviceId) return err('Избери услуга.');
                    const badP = v => v != null && !(v >= 0 && v <= 10000);
                    dto.price = numP(priceEl);
                    if (badP(dto.price)) return err('Невалидна цена.');
                    const xs = xRows().map(r => ({ serviceId: +r.querySelector('.ad-x-svc').value, price: numP(r.querySelector('.ad-x-price')) }));
                    if (xs.some(x => !x.serviceId)) return err('Избери услуга за всяка добавена процедура (или я махни с ×).');
                    if (xs.some(x => badP(x.price))) return err('Невалидна цена при добавена процедура.');
                    if (xs.length) dto.extras = xs;
                    if (dto.procedureMinutes < 5 * (xs.length + 1)) return err('Времетраенето е твърде кратко за всички процедури.');
                    if (!dto.guestName) return err('Въведи име на клиента.');
                    if (ED) {
                        const body = { serviceId: dto.serviceId, startAt, procedureMinutes: dto.procedureMinutes, price: dto.price, guestName: dto.guestName, guestPhone: dto.guestPhone, clientKey: dto.clientKey };
                        if (xs.length) body.extras = xs;   // добавени процедури за същия клиент
                        if (empSel) body.employeeId = employeeId;
                        run = () => window.API.put(`/bookings/${ED.id}/edit`, body);
                        saveBtn.disabled = true; saveBtn.style.opacity = .7;
                        try { await run(); close(); await load(); }
                        catch (e) { err(e.message); saveBtn.disabled = false; saveBtn.style.opacity = 1; }
                        return;
                    }
                    // Час върху „Запазено": първо се освобождава блокът, после се записва клиентът
                    // (ако записът не мине — блокът се връща обратно).
                    run = opts.replaceBlock
                        ? async () => {
                            const rb = opts.replaceBlock;
                            await window.API.del(`/schedule/block/${rb.id}?employeeId=${rb.employeeId}`);
                            try { await cfg.createBooking(dto); }
                            catch (e) {
                                try { await window.API.post('/schedule/block', { employeeId: rb.employeeId, blockType: 'reserved', note: rb.note || null, startAt: rb.startAt, endAt: rb.endAt }); } catch (_) {}
                                throw e;
                            }
                        }
                        : () => cfg.createBooking(dto);
                }
                saveBtn.disabled = true; saveBtn.style.opacity = .7;
                try { await run(); if (md === 'svc') rememberSvc(employeeId, svcSel.value); close(); await load(); }
                catch (e) { err(e.message); saveBtn.disabled = false; saveBtn.style.opacity = 1; }
            });
        }

        // Попъп: смяна на времето (дата / от / до) на „Запазено“ или почивка —
        // без да се освобождава и прави наново. PUT /schedule/block/{id}.
        function blockTimeModal(o, resv) {
            document.querySelectorAll('.cal-modal-backdrop').forEach(x => x.remove());
            const dayKey = o.startAt.slice(0, 10);
            const s0 = toMin(o.startAt);
            const e0 = o.endAt.slice(0, 10) > dayKey ? 1440 : toMin(o.endAt);
            const opts = (from, to, sel) => {
                const list = [];
                for (let m = from; m <= to; m += 15) list.push(m);
                if (!list.includes(sel)) { list.push(sel); list.sort((a, b) => a - b); }
                return list.map(m => `<option value="${m}"${m === sel ? ' selected' : ''}>${m === 1440 ? '24:00' : minToHHMM(m)}</option>`).join('');
            };
            const maxDate = (() => { const m = new Date(); m.setMonth(m.getMonth() + 6); return `${m.getFullYear()}-${pad(m.getMonth() + 1)}-${pad(m.getDate())}`; })();
            const backdrop = document.createElement('div');
            backdrop.className = 'cal-modal-backdrop';
            backdrop.innerHTML = `
                <div class="cal-modal">
                    <button class="cal-modal__close" aria-label="Затвори">×</button>
                    <div class="cal-modal__title">${resv ? 'Запазено време' : 'Почивка'} — смени времето</div>
                    ${cfg.showEmployee && o.employeeName ? `<div class="cal-modal__meta hint">${esc(o.employeeName)}</div>` : ''}
                    <label class="field" style="margin-top:.9rem"><span class="ad-lbl">Дата</span>
                        <input class="input bt-date" type="date" value="${dayKey}" max="${maxDate}"></label>
                    <div class="ad-pair" style="margin-top:.6rem">
                        <label class="field"><span class="ad-lbl">От</span>
                            <select class="select bt-from">${opts(BOOK_S, BOOK_E - 15, s0)}</select></label>
                        <label class="field"><span class="ad-lbl">До</span>
                            <select class="select bt-to">${opts(BOOK_S + 15, BOOK_E, e0)}</select></label>
                    </div>
                    <div class="hint bt-sum" style="margin-top:.5rem"></div>
                    <label class="field" style="margin-top:.8rem"><span class="ad-lbl">Пояснение <small>(по избор)</small></span>
                        <input class="input bt-note" type="text" maxlength="200" placeholder="напр. Почивам" value="${esc(o.note || '')}"></label>
                    ${chipsHtml()}
                    <div class="cal-modal__actions" style="margin-top:1rem"><button class="btn btn--primary bt-save">Запази промените</button></div>
                    <div class="md-msg" style="margin-top:.8rem"></div>
                </div>`;
            document.body.appendChild(backdrop);
            const $ = sel => backdrop.querySelector(sel);
            const close = () => backdrop.remove();
            backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
            $('.cal-modal__close').addEventListener('click', close);
            wireChips(backdrop, $('.bt-note'));
            const fromSel = $('.bt-from'), toSel = $('.bt-to'), btn = $('.bt-save');
            const msg = t => { $('.md-msg').innerHTML = t ? `<div class="alert alert--err">${esc(t)}</div>` : ''; };
            const paint = () => {
                const d = +toSel.value - +fromSel.value;
                const parts = [];
                if (d >= 60) parts.push(Math.floor(d / 60) + ' ч');
                if (d % 60) parts.push((d % 60) + ' мин');
                $('.bt-sum').textContent = d > 0 ? `Времетраене: ${parts.join(' ')}` : 'Краят трябва да е след началото.';
            };
            // Смяна на „От“ -> „До“ се мести със същото времетраене.
            let lastFrom = +fromSel.value;
            fromSel.addEventListener('change', () => {
                const dur = +toSel.value - lastFrom, nf = +fromSel.value;
                const want = Math.min(BOOK_E, nf + (dur > 0 ? dur : 60));
                if (![...toSel.options].some(x => +x.value === want)) toSel.insertAdjacentHTML('beforeend', `<option value="${want}">${minToHHMM(want)}</option>`);
                toSel.value = String(want);
                lastFrom = nf; paint();
            });
            toSel.addEventListener('change', paint);
            paint();
            btn.addEventListener('click', async () => {
                const date = $('.bt-date').value || dayKey;
                const f = +fromSel.value, t = +toSel.value;
                if (t <= f) return msg('Краят трябва да е след началото.');
                const startAt = `${date}T${minToHHMM(f)}:00`;
                const endAt = addMinIso(startAt, t - f);
                btn.disabled = true; msg('');
                try {
                    await window.API.put(`/schedule/block/${o.id}`, { employeeId: o.employeeId, startAt, endAt, note: $('.bt-note').value.trim() || null });
                    close(); await load();
                } catch (err) { msg(err.message); btn.disabled = false; }
            });
        }

        // Попъп за почивка / почивен ден: детайли + премахване.
        function openRestModal(o) {
            if (!o) return;
            document.querySelectorAll('.cal-modal-backdrop').forEach(x => x.remove());
            const isOff = o.kind === 'off', resv = !isOff && o.blockType === 'reserved';
            const d = parseK(isOff ? o.k : o.startAt.slice(0, 10));
            const time = isOff ? 'цял ден' : `${o.startAt.slice(11, 16)}–${o.endAt.slice(11, 16)}`;
            const backdrop = document.createElement('div');
            backdrop.className = 'cal-modal-backdrop';
            backdrop.innerHTML = `
                <div class="cal-modal">
                    <button class="cal-modal__close" aria-label="Затвори">×</button>
                    <div class="cal-modal__title">${isOff ? 'Почивен ден' : (resv ? 'Запазено време' : 'Почивка')}</div>
                    <div class="cal-modal__meta hint">${WDNAMES[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()].toLowerCase()} · ${time}${cfg.showEmployee ? ' · ' + esc(o.employeeName) : ''}</div>
                    ${!isOff && o.note ? `<div class="rm-note">${esc(o.note)}</div>` : ''}
                    ${(() => { const cl = isOff ? [] : clashesOf(o, true); return cl.length ? `<div class="md-clash" style="margin:.8rem 0 0"><b>⚠ Застъпва се с:</b>${cl.map(c => `<span>${clashLabel(c)}</span>`).join('')}<small>Премести часа или промени времето, за да не се застъпват.</small></div>` : ''; })()}
                    <div class="hint" style="margin:.7rem 0 1rem">${isOff ? 'В този ден никой не може да си запише час.' : (resv ? 'Часовете са заети — никой не може да си запише онлайн в това време. Клиент и процедура не са въведени.' : 'В това време никой не може да си запише час.')}</div>
                    ${cfg.editable ? `<div class="cal-modal__actions">${resv && canAdd() ? `<button class="btn btn--primary rm-fill">Добави клиент и процедура</button>` : ''}${!isOff ? `<button class="btn btn--ghost rm-time-edit">Редактирай времето</button>` : ''}${!isOff ? `<button class="btn btn--ghost rm-note-edit">${o.note ? 'Смени пояснението' : 'Добави пояснение'}</button>` : ''}<button class="btn btn--ghost rm-del" style="color:#D9534F">${isOff ? 'Направи го работен ден' : (resv ? 'Освободи часовете' : 'Премахни почивката')}</button></div>` : ''}
                    <div class="md-msg" style="margin-top:.8rem"></div>
                </div>`;
            document.body.appendChild(backdrop);
            const close = () => backdrop.remove();
            backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
            backdrop.querySelector('.cal-modal__close').addEventListener('click', close);
            const timeEdit = backdrop.querySelector('.rm-time-edit');
            if (timeEdit) timeEdit.addEventListener('click', () => blockTimeModal(o, resv));
            const noteEdit = backdrop.querySelector('.rm-note-edit');
            if (noteEdit) noteEdit.addEventListener('click', () => noteModal({
                title: resv ? 'Запазено време' : 'Почивка',
                sub: `${WDNAMES[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()].toLowerCase()} · ${time}`,
                value: o.note, saveLabel: 'Запази пояснението',
                onSave: async (note) => {
                    await window.API.put(`/schedule/block/${o.id}/note`, { employeeId: o.employeeId, note });
                    await load();
                }
            }));
            const fill = backdrop.querySelector('.rm-fill');
            if (fill) fill.addEventListener('click', () => {
                close();
                const s = toMin(o.startAt), e = o.endAt.slice(0, 10) > o.startAt.slice(0, 10) ? 1440 : toMin(o.endAt);
                openAddModal(minToHHMM(s), { dayKey: o.startAt.slice(0, 10), dur: e - s, empId: o.employeeId, replaceBlock: o });
            });
            const del = backdrop.querySelector('.rm-del');
            if (del) del.addEventListener('click', async () => {
                del.disabled = true;
                try {
                    if (isOff) await window.API.del(`/schedule/override?employeeId=${o.employeeId}&date=${o.k}`);
                    else await window.API.del(`/schedule/block/${o.id}?employeeId=${o.employeeId}`);
                    close(); await load();
                } catch (err) {
                    backdrop.querySelector('.md-msg').innerHTML = `<div class="alert alert--err">${esc(err.message)}</div>`;
                    del.disabled = false;
                }
            });
        }

        async function act(btn, fn) {
            btn.disabled = true; btn.style.opacity = .7;
            try { await fn(); await load(); }
            catch (err) { alert(err.message); btn.disabled = false; btn.style.opacity = 1; }
        }

        // Опции за продължителност (за редакция в попъпа).
        function durOptions(cur) {
            const opts = [15, 20, 30, 40, 45, 60, 75, 90, 105, 120, 150, 180];
            let o = opts.includes(cur) ? '' : `<option value="${cur}" selected>${cur} мин</option>`;
            opts.forEach(m => { o += `<option value="${m}"${m === cur ? ' selected' : ''}>${m} мин</option>`; });
            return o;
        }

        // Попъп за час: детайли + присъства/не присъства + отстъпка + времетраене + изтрий.
        function openBookingModal(b) {
            if (!b) return;
            document.querySelectorAll('.cal-modal-backdrop').forEach(x => x.remove());

            const st = STATUS[b.status] || { label: b.status, cls: 'alert--info' };
            const flagged = b.noShowCount > 0;
            const orig = b.priceSnapshot || 0;
            const curDisc = b.discountPercent || 0;
            const finalPrice = (b.priceFinal != null) ? b.priceFinal : orig;
            const dur = Math.round((new Date(b.endAt) - new Date(b.startAt)) / 60000) || 30;
            const canManage = !!cfg.canManage;
            const phone = b.clientPhone ? `<a href="tel:${esc(b.clientPhone)}">${esc(b.clientPhone)}</a>` : '—';

            const warn = flagged
                ? `<div style="background:#D9534F;color:#fff;font-weight:800;font-size:.78rem;padding:.5rem .8rem;border-radius:12px;margin-bottom:1rem">⚠ Некоректен клиент · ${b.noShowCount}× не се е явявал(а)</div>` : '';
            // Застъпване с друг час на същата специалистка -> с кой и какво да се направи.
            const clashes = clashesOf(b);
            const clashWarn = clashes.length
                ? `<div class="md-clash"><b>⚠ Застъпва се с:</b>${clashes.map(c => `<span>${clashLabel(c)}</span>`).join('')}
                    <small>Премести или скъси единия, за да не се застъпват.</small></div>` : '';

            // Цена, която може да се поправи при затваряне на часа („Присъства“) —
            // напр. клиентът е платил друга сума. Важи и за минали часове.
            const canFixPrice = !!(cfg.editable && cfg.setStatus && (b.status === 'booked' || b.status === 'completed'));
            const r2 = v => { const n = Number(v) || 0; return Math.sign(n) * Math.round(Math.abs(n) * 100 + 1e-6) / 100; };
            const priceBlock = canFixPrice
                ? `<div class="cal-modal__price">
                       ${canManage ? `<label style="display:flex;align-items:center;justify-content:space-between;gap:.6rem;font-size:.9rem;margin-bottom:.8rem">Отстъпка (лоялен клиент)
                           <span style="white-space:nowrap"><input class="input md-disc" type="number" min="0" max="100" step="any" inputmode="decimal" value="${curDisc}" style="width:74px;text-align:center"> %</span></label>` : ''}
                       <label class="md-pricefix">
                           <span>Цена за плащане${curDisc ? ` <small class="md-orig">${r2(orig)} € −${curDisc}%</small>` : ''}</span>
                           <span class="ad-eur"><input class="input md-price" type="number" min="0" step="0.01" inputmode="decimal" value="${r2(finalPrice)}"><i>€</i></span>
                       </label>
                       <div class="hint" style="font-size:.76rem;margin-top:.45rem">${b.status === 'completed'
                           ? 'Часът е приключен. Ако сумата е друга — поправи я и натисни „Запази цената“.'
                           : 'Взе друга сума (напр. 15 € вместо 20 €)? Поправи я тук и натисни „Приключи часа“.'}</div>
                   </div>`
                : `<div class="cal-modal__price" style="display:flex;justify-content:space-between;align-items:baseline;font-size:1.05rem">
                       <span class="hint">Цена</span><b style="color:var(--rose-deep);font-family:var(--font-display);font-size:1.4rem">${r2(finalPrice).toLocaleString('bg-BG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €</b></div>`;

            const canCancelWithReason = cfg.editable && cfg.cancelBooking && b.status === 'booked';
            let actions = '';
            if (cfg.editable) {
                // Редакция: ръчни и онлайн часове (напр. сбъркана процедура); в чужд график — само ръчни.
                const canEdit = b.status === 'booked' && canAdd();
                // Изтриване: шефът — всеки час (deleteAny); служителката — предстоящите в своя график.
                const canDel = !!cfg.deleteBk && (cfg.deleteAny || b.status === 'booked');
                actions = `<div class="cal-modal__actions">
                    ${canEdit ? `<button class="btn btn--primary md-edit">Редактирай часа</button>` : ''}
                    ${cfg.setStatus && !(cfg.hidePrices && b.status === 'completed') ? `<button class="btn btn--gold md-present">${b.status === 'completed' ? 'Запази цената' : 'Приключи часа'}</button>
                    <button class="btn btn--ghost md-absent">Не присъства</button>` : ''}
                    ${canCancelWithReason ? `<button class="btn btn--ghost md-cancel" style="color:#D9534F">${b.isOnline ? 'Отмени часа на клиента' : 'Отмени часа'}</button>` : ''}
                    ${canManage ? `
                    <div class="hint" style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin-top:.4rem">Времетраене
                        <span class="ad-hm">
                            <select class="md-h" aria-label="Часове">${Array.from({ length: 9 }, (_, h) => `<option value="${h}"${h === Math.floor(dur / 60) ? ' selected' : ''}>${h} ч</option>`).join('')}</select><span class="ad-hm__sep"></span>
                            <select class="md-m" aria-label="Минути">${[...new Set([...Array.from({ length: 12 }, (_, i) => i * 5), dur % 60])].sort((a, b) => a - b).map(m => `<option value="${m}"${m === dur % 60 ? ' selected' : ''}>${String(m).padStart(2, '0')} мин</option>`).join('')}</select>
                        </span></div>` : ''}
                    ${canDel ? `<button class="btn btn--ghost md-del" style="color:#D9534F">Изтрий часа</button>` : ''}
                </div>`;
            }

            const backdrop = document.createElement('div');
            backdrop.className = 'cal-modal-backdrop';
            backdrop.innerHTML = `
                <div class="cal-modal">
                    <button class="cal-modal__close" aria-label="Затвори">×</button>
                    ${warn}${clashWarn}
                    <div class="cal-modal__title">${esc(b.serviceName)}</div>
                    <div class="cal-modal__meta hint">${b.startAt.slice(11, 16)}–${(b.endAt || '').slice(11, 16)}${cfg.showEmployee ? ' · ' + esc(b.employeeName) : ''} <span class="alert ${st.cls}" style="padding:.12rem .5rem;font-size:.72rem">${st.label}</span></div>
                    <div class="cal-modal__rows">
                        <div class="cmrow"><span class="hint">Клиент</span><b>${esc(b.clientName || 'Клиент')}${b.clientId > 0 ? ' ' + profBadge() : ''}</b></div>
                        <div class="cmrow"><span class="hint">Телефон</span><span>${phone}</span></div>
                        <div class="cmrow"><span class="hint">Източник</span>${b.isOnline
                            ? `<span style="display:inline-flex;align-items:center;gap:.35rem;background:var(--blush-soft);color:var(--rose-deep);border-radius:999px;padding:.22rem .65rem;font-size:.76rem;font-weight:700"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="9"/><path d="M3.2 12h17.6M12 3.1c2.4 2.6 2.4 15.2 0 17.8M12 3.1c-2.4 2.6-2.4 15.2 0 17.8"/></svg> Онлайн през сайта</span>`
                            : `<span style="display:inline-flex;align-items:center;gap:.35rem;background:var(--line);color:var(--ink-soft);border-radius:999px;padding:.22rem .65rem;font-size:.76rem;font-weight:700">Въведен ръчно</span>`}</div>
                    </div>
                    ${cfg.hidePrices ? '' : priceBlock}
                    ${actions}
                    <div class="md-msg" style="margin-top:.8rem"></div>
                    <div class="md-hist" hidden></div>
                </div>`;
            document.body.appendChild(backdrop);
            loadHistory(b, backdrop.querySelector('.md-hist'), () => document.body.contains(backdrop));

            const close = () => backdrop.remove();
            backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
            backdrop.querySelector('.cal-modal__close').addEventListener('click', close);

            const discInp = backdrop.querySelector('.md-disc');
            const priceInp = backdrop.querySelector('.md-price');
            if (discInp && priceInp) {
                // Смяна на отстъпката -> преизчислява цената за плащане.
                discInp.addEventListener('input', () => {
                    const d = Math.max(0, Math.min(100, +String(discInp.value).replace(',', '.') || 0));
                    priceInp.value = r2(orig * (100 - d) / 100);
                });
            }

            const msg = backdrop.querySelector('.md-msg');
            const run = async (fn) => {
                try { await fn(); close(); await load(); }
                catch (err) { msg.innerHTML = `<div class="alert alert--err">${esc(err.message)}</div>`; }
            };
            const saveDiscount = async () => {
                if (discInp && cfg.setDiscount) {
                    const d = Math.max(0, Math.min(100, +String(discInp.value).replace(',', '.') || 0));
                    if (d !== curDisc) await cfg.setDiscount(b.id, d);
                }
            };

            const editBtn = backdrop.querySelector('.md-edit');
            if (editBtn) editBtn.addEventListener('click', () => {
                close();
                openAddModal(b.startAt.slice(11, 16), { dayKey: b.startAt.slice(0, 10), dur, empId: b.employeeId, edit: b });
            });
            const present = backdrop.querySelector('.md-present');
            if (present) present.addEventListener('click', () => {
                // Ръчно поправена цена -> записва се тя (отстъпката се нулира); иначе — отстъпката както досега.
                let fixed = null;
                if (priceInp) {
                    const raw = String(priceInp.value).trim().replace(',', '.');
                    const pv = raw === '' ? null : +raw;
                    if (pv != null && !(pv >= 0 && pv <= 10000)) { msg.innerHTML = `<div class="alert alert--err">Невалидна цена.</div>`; return; }
                    const d = discInp ? Math.max(0, Math.min(100, +discInp.value || 0)) : curDisc;
                    if (pv != null && Math.abs(pv - r2(orig * (100 - d) / 100)) > 0.004) fixed = pv;
                }
                run(async () => {
                    if (fixed != null) await cfg.setStatus(b.id, 'completed', fixed);
                    else { await saveDiscount(); await cfg.setStatus(b.id, 'completed'); }
                });
            });
            const absent = backdrop.querySelector('.md-absent');
            if (absent) absent.addEventListener('click', () => run(() => cfg.setStatus(b.id, 'no_show')));
            const cancelWithReason = backdrop.querySelector('.md-cancel');
            if (cancelWithReason) cancelWithReason.addEventListener('click', () => {
                // Ръчно въведен час -> без причина и без имейл, само потвърждение.
                if (!b.isOnline) {
                    if (confirm('Да отменя ли този час?')) run(() => cfg.cancelBooking(b.id, ''));
                    return;
                }
                const reason = window.prompt('Причина за отмяната — клиентът ще я види в имейла/SMS-а:');
                if (reason === null) return; // отказ
                if (!reason.trim()) { msg.innerHTML = `<div class="alert alert--err">Трябва да въведеш причина.</div>`; return; }
                run(() => cfg.cancelBooking(b.id, reason.trim()));
            });
            const del = backdrop.querySelector('.md-del');
            if (del) del.addEventListener('click', () => { if (confirm('Да изтрия ли този час?')) run(() => cfg.deleteBk(b.id)); });
            const mdH = backdrop.querySelector('.md-h'), mdM = backdrop.querySelector('.md-m');
            if (mdH && mdM) {
                const onDur = () => {
                    const total = (+mdH.value || 0) * 60 + (+mdM.value || 0);
                    if (total < 5) { msg.innerHTML = `<div class="alert alert--err">Времетраенето трябва да е поне 5 минути.</div>`; return; }
                    if (total !== dur) run(() => cfg.setDuration(b.id, total));
                };
                mdH.addEventListener('change', onDur); mdM.addEventListener('change', onDur);
            }
        }

        // Минали часове на клиентката (явила се или не) — най-отдолу в попъпа на часа.
        async function loadHistory(b, box, alive) {
            if (!box || !b.clientKey || b.clientKey === 'n') return;
            box.hidden = false;
            box.innerHTML = `<div class="md-hist__h">Минали часове</div><div class="hint" style="font-size:.8rem">Зареждане…</div>`;
            let h;
            try { h = await window.API.get(`/clients/history?key=${encodeURIComponent(b.clientKey)}`); }
            catch (e) { if (alive()) box.hidden = true; return; }
            if (!alive()) return;
            const now = new Date();
            const past = (h && h.bookings || [])
                .filter(x => x.id !== b.id && new Date(x.startAt) < now)
                .sort((x, y) => new Date(y.startAt) - new Date(x.startAt));
            const HS = {
                completed: ['Дошла', 'is-ok'], no_show: ['Не дошла', 'is-no'],
                cancelled: ['Отменен', 'is-x'], booked: ['Без отметка', 'is-x']
            };
            const nOk = past.filter(x => x.status === 'completed').length;
            const nNo = past.filter(x => x.status === 'no_show').length;
            const d = iso => { const t = new Date(iso); return `${pad(t.getDate())}.${pad(t.getMonth() + 1)}.${String(t.getFullYear()).slice(2)}`; };
            const row = x => {
                const [lbl, cls] = HS[x.status] || [x.status, 'is-x'];
                const pr = (!cfg.hidePrices && x.price != null) ? `<em>${(+x.price).toLocaleString('bg-BG', { maximumFractionDigits: 2 })} €</em>` : '';
                return `<li><span class="md-hist__d">${d(x.startAt)}</span>
                    <span class="md-hist__s">${esc(x.serviceName)}<small>${esc(firstName(x.employeeName))}</small></span>
                    ${pr}<i class="md-hist__st ${cls}">${lbl}</i></li>`;
            };
            const SHOW = 6;
            box.innerHTML = `<div class="md-hist__h">Минали часове <span>${past.length}</span></div>`
                + (past.length
                    ? `<div class="md-hist__sum"><b class="is-ok">${nOk} дошла</b>${nNo ? `<b class="is-no">${nNo} не дошла</b>` : ''}</div>
                       <ul class="md-hist__list">${past.slice(0, SHOW).map(row).join('')}</ul>
                       ${past.length > SHOW ? `<button type="button" class="md-hist__more">Покажи всички (${past.length})</button>` : ''}`
                    : `<div class="hint" style="font-size:.82rem">Първо посещение — няма минали часове.</div>`);
            const more = box.querySelector('.md-hist__more');
            if (more) more.addEventListener('click', () => {
                box.querySelector('.md-hist__list').innerHTML = past.map(row).join('');
                more.remove();
            });
        }

        function renderForm(box) {
            if (!box) return;
            if (box.dataset.open === '1') { box.innerHTML = ''; box.dataset.open = '0'; return; }
            box.dataset.open = '1';
            const svcOpts = (cfg.services || [])
                .map(s => `<option value="${s.serviceId}">${esc(s.serviceName)} · ${s.durationMinutes} мин</option>`).join('');
            box.innerHTML = `
                <div class="panel" style="margin-top:1rem;display:grid;gap:.9rem">
                    <label class="field" style="margin:0">
                        <span style="display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.4rem">Услуга</span>
                        <select class="select f-svc">${svcOpts || '<option value="">Нямаш зададени услуги</option>'}</select>
                    </label>
                    <label class="field" style="margin:0">
                        <span style="display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.4rem">Свободен час</span>
                        <select class="select f-slot"><option value="">Избери услуга…</option></select>
                    </label>
                    <label class="field" style="margin:0">
                        <span style="display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.4rem">Име на клиента</span>
                        <input class="input f-name" type="text" placeholder="напр. Мария (по телефон)">
                    </label>
                    <label class="field" style="margin:0">
                        <span style="display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.4rem">Телефон (по избор)</span>
                        <input class="input f-phone" type="tel" placeholder="+359…">
                    </label>
                    <label class="field" style="margin:0">
                        <span style="display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.4rem">Бележка (по избор)</span>
                        <input class="input f-note" type="text">
                    </label>
                    <button class="btn btn--primary f-save" style="justify-self:start">Запиши часа</button>
                    <div class="f-msg"></div>
                </div>`;

            const svc = box.querySelector('.f-svc');
            const slot = box.querySelector('.f-slot');
            const msg = box.querySelector('.f-msg');

            async function loadSlots() {
                const sid = svc.value;
                if (!sid) { slot.innerHTML = `<option value="">—</option>`; return; }
                slot.innerHTML = `<option value="">Зареждане…</option>`;
                try {
                    const times = await window.API.get(`/availability?employeeId=${cfg.staffId}&serviceId=${sid}&date=${selKey}`);
                    slot.innerHTML = (times && times.length)
                        ? times.map(t => `<option value="${t}">${t.slice(11, 16)}</option>`).join('')
                        : `<option value="">Няма свободни часове</option>`;
                } catch (err) {
                    slot.innerHTML = `<option value="">Грешка</option>`;
                }
            }
            svc.addEventListener('change', loadSlots);
            selectLastSvc(svc, cfg.staffId);   // последно избраната процедура
            svcPicker(svc, () => cfg.staffId);
            loadSlots();

            box.querySelector('.f-save').addEventListener('click', async (e) => {
                const btn = e.currentTarget;
                const dto = {
                    serviceId: +svc.value,
                    startAt: slot.value,
                    guestName: box.querySelector('.f-name').value.trim(),
                    guestPhone: box.querySelector('.f-phone').value.trim() || null,
                    note: box.querySelector('.f-note').value.trim() || null
                };
                if (!dto.serviceId || !dto.startAt) { msg.innerHTML = `<div class="alert alert--err">Избери услуга и свободен час.</div>`; return; }
                if (!dto.guestName) { msg.innerHTML = `<div class="alert alert--err">Въведи име на клиента.</div>`; return; }
                btn.disabled = true; btn.style.opacity = .7;
                try {
                    await cfg.createBooking(dto);
                    rememberSvc(cfg.staffId, svc.value);
                    await load();
                } catch (err) {
                    msg.innerHTML = `<div class="alert alert--err">${esc(err.message)}</div>`;
                    btn.disabled = false; btn.style.opacity = 1;
                }
            });
        }

        function reloadAll() { load(); }

        // Панел „Работно време" за избрания ден: ефективни часове + свободни
        // слотове (клик = блокирай) + блокирани (клик = освободи) + промяна.
        async function loadSchedule(box, dayKey) {
            box.innerHTML = `<div class="spinner"></div>`;
            let info;
            try {
                info = await window.API.get(`/schedule/day?employeeId=${cfg.staffId}&date=${dayKey}`);
            } catch (err) {
                box.innerHTML = `<div class="hint">Работното време е недостъпно (${esc(err.message)}).</div>`;
                return;
            }
            const wd = new Date(dayKey + 'T00:00:00').getDay();
            const hoursText = info.isOff ? 'Почивен ден' : `${minToHHMM(info.startMin)} – ${minToHHMM(info.endMin)}`;

            const chip = 'display:inline-flex;align-items:center;gap:.3rem;border-radius:999px;padding:.28rem .7rem;font-size:.8rem;cursor:pointer;border:1px solid var(--line);background:var(--ivory)';
            const chipBlk = 'display:inline-flex;align-items:center;gap:.3rem;border-radius:999px;padding:.28rem .7rem;font-size:.8rem;cursor:pointer;border:1px solid transparent;background:var(--grad-rose);color:#fff';

            const free = (info.freeSlots || []).map(s =>
                `<button class="sc-block" data-t="${s}" title="Блокирай (почивка)" style="${chip}">${s.slice(11, 16)} ✕</button>`
            ).join('') || '<span class="hint">Няма свободни слотове.</span>';

            const blocks = (info.blocks || []).map(b =>
                `<button class="sc-unblock" data-id="${b.id}" title="Освободи" style="${chipBlk}">${b.startAt.slice(11, 16)} ↺</button>`
            ).join('');

            box.innerHTML = `
                <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap">
                    <strong>Работно време: <span style="color:var(--rose-deep)">${hoursText}</span></strong>
                    <div style="display:flex;gap:.4rem;flex-wrap:wrap">
                        <button class="btn btn--ghost sc-edit" style="--pad-y:.4rem;--pad-x:.8rem;font-size:.8rem">Промени часове</button>
                        <button class="btn btn--ghost sc-off" style="--pad-y:.4rem;--pad-x:.8rem;font-size:.8rem">${info.isOff ? 'Направи работен' : 'Почивен ден'}</button>
                    </div>
                </div>
                <div class="sc-form"></div>
                ${info.isOff ? '' : `
                <div style="margin-top:.9rem">
                    <div class="hint" style="margin-bottom:.4rem">Свободни слотове:</div>
                    <div style="display:flex;flex-wrap:wrap;gap:.4rem">${free}</div>
                    ${blocks ? `<div class="hint" style="margin:.8rem 0 .4rem">Почивки:</div><div style="display:flex;flex-wrap:wrap;gap:.4rem">${blocks}</div>` : ''}
                </div>`}`;

            box.querySelector('.sc-off').addEventListener('click', async () => {
                try {
                    if (info.isOff) await window.API.del(`/schedule/override?employeeId=${cfg.staffId}&date=${dayKey}`);
                    else await window.API.put('/schedule/override', { employeeId: cfg.staffId, date: dayKey, isOff: true });
                    reloadAll();
                } catch (err) { alert(err.message); }
            });
            box.querySelector('.sc-edit').addEventListener('click', () => schedForm(box.querySelector('.sc-form'), info, dayKey, wd));
            box.querySelectorAll('.sc-block').forEach(btn => btn.addEventListener('click', async () => {
                try {
                    await window.API.post('/schedule/block', { employeeId: cfg.staffId, startAt: btn.dataset.t, endAt: addMinIso(btn.dataset.t, 30) });
                    reloadAll();
                } catch (err) { alert(err.message); }
            }));
            box.querySelectorAll('.sc-unblock').forEach(btn => btn.addEventListener('click', async () => {
                try { await window.API.del(`/schedule/block/${btn.dataset.id}?employeeId=${cfg.staffId}`); reloadAll(); }
                catch (err) { alert(err.message); }
            }));
        }

        function schedForm(box, info, dayKey, wd) {
            if (box.dataset.open === '1') { box.innerHTML = ''; box.dataset.open = '0'; return; }
            box.dataset.open = '1';
            const from = info.isOff ? '09:00' : minToHHMM(info.startMin);
            const to = info.isOff ? '18:00' : minToHHMM(info.endMin);
            const lbl = 'display:block;font-size:.82rem;font-weight:600;color:var(--ink-soft);margin-bottom:.35rem';
            box.innerHTML = `
                <div class="panel" style="margin-top:.8rem;display:grid;gap:.7rem;max-width:360px">
                    <label class="field" style="margin:0"><span style="${lbl}">От</span><select class="select sc-from">${timeOptions(from)}</select></label>
                    <label class="field" style="margin:0"><span style="${lbl}">До</span><select class="select sc-to">${timeOptions(to)}</select></label>
                    <label class="field" style="margin:0"><span style="${lbl}">Приложи за</span>
                        <select class="select sc-scope">
                            <option value="day">Само този ден</option>
                            <option value="week">Всеки ${WDNAMES[wd]} нататък</option>
                        </select>
                    </label>
                    <button class="btn btn--primary sc-save" style="justify-self:start">Запази</button>
                </div>`;
            box.querySelector('.sc-save').addEventListener('click', async () => {
                const sm = hhmmToMin(box.querySelector('.sc-from').value);
                const em = hhmmToMin(box.querySelector('.sc-to').value);
                if (sm == null || em == null || em <= sm) { alert('Невалидни часове (краят трябва да е след началото).'); return; }
                const scope = box.querySelector('.sc-scope').value;
                try {
                    if (scope === 'day')
                        await window.API.put('/schedule/override', { employeeId: cfg.staffId, date: dayKey, startMin: sm, endMin: em, isOff: false });
                    else
                        await window.API.put('/schedule/hours', { employeeId: cfg.staffId, days: [{ weekday: wd, startMin: sm, endMin: em, isOff: false }] });
                    reloadAll();
                } catch (err) { alert(err.message); }
            });
        }

        load();
    }

    return { mount, empColor, EMP_COLORS, learnEmp };
})();
