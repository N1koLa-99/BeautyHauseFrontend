/* =====================================================================
   Екип: тегли всички активни служители от /employees и ги показва.
   ===================================================================== */
document.addEventListener('DOMContentLoaded', async () => {
    const box = document.getElementById('team-list');
    if (!box) return;

    let list = null;
    const paint = () => {
        if (!list) return;
        box.innerHTML = (isMobileLayout() ? teamMobileOrder([...list]) : list).map((e, i) => teamCardHTML(e, i % 3)).join('');
        box.scrollLeft = 0;
        revealNew(box);
    };

    try {
        const employees = await API.get('/employees');
        if (!employees || employees.length === 0) {
            box.innerHTML = `<p class="hint center" style="grid-column:1/-1">Скоро тук ще видиш нашия екип.</p>`;
            return;
        }
        list = employees;
    } catch (err) {
        // Без сървър → резервен екип.
        const fb = (window.BH_FALLBACK && BH_FALLBACK.employees) || [];
        if (!fb.length) {
            box.innerHTML = `<div class="alert alert--err" style="grid-column:1/-1">${esc(err.message)}</div>`;
            return;
        }
        list = fb;
    }
    paint();
    onLayoutChange(paint);
});
